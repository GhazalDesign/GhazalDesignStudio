#include <QtTest>
#include <QTemporaryDir>
#include "Document.h"

class CoreTests : public QObject {
    Q_OBJECT
private slots:
    void createUndoRedo()
    {
        Document d;
        const NodeId a = d.createNode("Box");
        QCOMPARE(d.scene().count(), 2);
        QCOMPARE(d.scene().node(a).name, QString("Box001"));
        QVERIFY(d.undo());
        QCOMPARE(d.scene().count(), 1);
        QVERIFY(d.redo());
        QCOMPARE(d.scene().count(), 2);
        QCOMPARE(d.scene().node(a).name, QString("Box001"));      // same id and name after redo
        QCOMPARE(d.createNode("Box") == a, false);
        QCOMPARE(d.scene().node(d.createNode("Box")).name, QString("Box003"));
    }

    void deleteSubtreeRestores()
    {
        Document d;
        const NodeId a = d.createNode("Base Unit");
        const NodeId b = d.createNode("Drawer", a);
        QCOMPARE(d.scene().count(), 3);
        d.setSelection({ a });
        QVERIFY(d.deleteSelection());
        QCOMPARE(d.scene().count(), 1);
        QVERIFY(d.undo());
        QCOMPARE(d.scene().count(), 3);
        QCOMPARE(d.scene().node(b).parent, a);
        QCOMPARE(d.scene().node(a).children.size(), qsizetype(1));
    }

    void deleteSelectionIgnoresCoveredChildren()
    {
        Document d;
        const NodeId a = d.createNode("Base Unit");
        const NodeId b = d.createNode("Drawer", a);
        d.setSelection({ a, b });                                   // child is covered by its parent
        QVERIFY(d.deleteSelection());
        QCOMPARE(d.scene().count(), 1);
        QVERIFY(d.undo());
        QCOMPARE(d.scene().count(), 3);
    }

    void saveLoadRoundTrip()
    {
        QTemporaryDir dir;
        QVERIFY(dir.isValid());
        const QString path = dir.filePath("t.gds");
        QString err;

        Document d;
        d.createNode("Box");
        d.createNode("Sphere");
        QVERIFY2(d.save(path, &err), qPrintable(err));

        Document e;
        QVERIFY2(e.load(path, &err), qPrintable(err));
        QCOMPARE(e.scene().count(), 3);
        QVERIFY(!e.isDirty());
        QVERIFY(e.createNode("Cone") > 3);                          // ids continue after the loaded ones
    }

    void corruptFileDoesNotTouchDocument()
    {
        QTemporaryDir dir;
        const QString bad = dir.filePath("bad.gds");
        QFile f(bad);
        QVERIFY(f.open(QIODevice::WriteOnly));
        f.write("this is not json");
        f.close();

        Document d;
        d.createNode("Box");
        QString err;
        QVERIFY(!d.load(bad, &err));
        QVERIFY(!err.isEmpty());
        QCOMPARE(d.scene().count(), 2);                             // still the open project
    }

    void dirtyTracking()
    {
        QTemporaryDir dir;
        QString err;
        Document d;
        QVERIFY(!d.isDirty());
        d.createNode("Box");
        QVERIFY(d.isDirty());
        QVERIFY(d.save(dir.filePath("a.gds"), &err));
        QVERIFY(!d.isDirty());
        d.undo();
        QVERIFY(d.isDirty());
        d.redo();
        QVERIFY(!d.isDirty());
    }

    void renameRejectsEmpty()
    {
        Document d;
        const NodeId id = d.createNode("Box");
        QVERIFY(!d.renameNode(id, "   "));
        QCOMPARE(d.scene().node(id).name, QString("Box001"));
        QVERIFY(d.renameNode(id, "Kitchen"));
        QVERIFY(d.undo());
        QCOMPARE(d.scene().node(id).name, QString("Box001"));
    }

    void layersLifecycle()
    {
        Document d;
        QCOMPARE(d.scene().layers().size(), qsizetype(1));
        const LayerId L = d.createLayer();
        QVERIFY(L != 0);
        QCOMPARE(d.scene().layers().size(), qsizetype(2));
        d.setCurrentLayer(L);
        const NodeId n = d.createNode("Box");
        QCOMPARE(d.scene().node(n).layer, L);                       // new objects go on the current layer
        QVERIFY(d.deleteLayer(L));
        QCOMPARE(d.scene().node(n).layer, kDefaultLayer);           // moved to the default layer
        QVERIFY(d.undo());
        QCOMPARE(d.scene().node(n).layer, L);                       // and back again
        QCOMPARE(d.scene().layers().size(), qsizetype(2));
        QVERIFY(!d.deleteLayer(kDefaultLayer));                     // the default layer is protected
    }

    void frozenLayerBlocksSelection()
    {
        Document d;
        const NodeId n = d.createNode("Box");
        Layer l = d.scene().layer(kDefaultLayer);
        l.frozen = true;
        QVERIFY(d.editLayer(l));
        QVERIFY(d.selection().isEmpty());                           // selection pruned
        d.setSelection({ n });
        QVERIFY(d.selection().isEmpty());                           // and cannot be selected
        QCOMPARE(d.createNode("Box"), kNoNode);                     // current layer is frozen: refused
        QVERIFY(d.undo());                                          // unfreeze
        d.setSelection({ n });
        QCOMPARE(d.selection().size(), qsizetype(1));
    }

    void layersSurviveSaveLoad()
    {
        QTemporaryDir dir;
        QString err;
        Document d;
        const LayerId L = d.createLayer();
        const NodeId n = d.createNode("Box");
        d.setSelection({ n });
        QVERIFY(d.assignSelectionToLayer(L));
        QVERIFY(d.save(dir.filePath("l.gds"), &err));

        Document e;
        QVERIFY2(e.load(dir.filePath("l.gds"), &err), qPrintable(err));
        QCOMPARE(e.scene().layers().size(), qsizetype(2));
        QCOMPARE(e.scene().node(n).layer, L);
        QCOMPARE(e.scene().layer(L).name, d.scene().layer(L).name);
    }

    void rootIsProtected()
    {
        Document d;
        QVERIFY(!d.renameNode(Scene::Root, "x"));
        QCOMPARE(d.createNode("Box", /*parent*/ 999), kNoNode);     // unknown parent is refused, not a crash
        QCOMPARE(d.scene().count(), 1);
    }
};

QTEST_GUILESS_MAIN(CoreTests)
#include "test_core.moc"
