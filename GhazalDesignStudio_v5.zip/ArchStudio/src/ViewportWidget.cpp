#include "ViewportWidget.h"
#include <QPainter>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QLinearGradient>
#include <QPointF>
#include <optional>
#include <algorithm>
#include <cmath>

ViewportWidget::ViewportWidget(ViewType type, QWidget* parent)
    : QWidget(parent), m_type(type)
{
    setMinimumSize(120, 90);
    setMouseTracking(false);
}

void ViewportWidget::setActive(bool a) { m_active = a; update(); }

QString ViewportWidget::title() const
{
    switch (m_type) {
    case ViewType::Top:         return "[+][Top][Wireframe]";
    case ViewType::Front:       return "[+][Front][Wireframe]";
    case ViewType::Left:        return "[+][Left][Wireframe]";
    case ViewType::Perspective: return "[+][Perspective][Realistic]";
    }
    return {};
}

void ViewportWidget::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    if (m_type == ViewType::Perspective) {
        QLinearGradient g(0, 0, 0, height());
        g.setColorAt(0, QColor(m_pal.vpTop));
        g.setColorAt(1, QColor(m_pal.vpBottom));
        p.fillRect(rect(), g);
    } else {
        p.fillRect(rect(), QColor(m_pal.vpBg));
    }

    const double cx = width() / 2.0, cy = height() / 2.0;
    const double unit = 24.0 * m_zoom;      // pixels per grid cell (ortho)
    const int N = 30;

    // Projects a grid-plane point (a,b) to the screen; nullopt if behind camera.
    auto project = [&](double a, double b) -> std::optional<QPointF> {
        if (m_type != ViewType::Perspective)
            return QPointF(cx + a * unit, cy - b * unit);
        const double cy_ = std::cos(m_yaw), sy_ = std::sin(m_yaw);
        const double x = a * cy_ - b * sy_;
        const double y = a * sy_ + b * cy_;
        const double depth = 40.0 / m_zoom + y * std::cos(m_pitch);
        if (depth < 1.0) return std::nullopt;
        const double f = std::min(width(), height()) * 1.3;
        return QPointF(cx + f * x / depth, cy * 1.1 - f * (y * std::sin(m_pitch)) / depth);
    };
    auto line = [&](double a1, double b1, double a2, double b2) {
        auto s = project(a1, b1); auto e = project(a2, b2);
        if (s && e) p.drawLine(*s, *e);
    };

    for (int i = -N; i <= N; ++i) {
        const bool major = (i % 5 == 0);
        p.setPen(QPen(major ? QColor(m_pal.vpMajor) : QColor(m_pal.vpGrid), 1));
        if (i == 0) p.setPen(QPen(QColor(m_pal.vpAxis), 1.5));
        line(i, -N, i, N);
        line(-N, i, N, i);
    }

    // axis tripod
    if (auto o = project(0, 0)) {
        p.setPen(QPen(QColor(200, 60, 60), 2));
        if (auto x = project(2, 0)) p.drawLine(*o, *x);
        p.setPen(QPen(QColor(70, 200, 70), 2));
        if (auto y = project(0, 2)) p.drawLine(*o, *y);
    }

    p.setPen(QColor(m_pal.vpText));
    p.drawText(8, 16, title());

    if (m_active) {
        p.setPen(QPen(QColor(217, 164, 65), 3));
        p.setBrush(Qt::NoBrush);
        p.drawRect(rect().adjusted(1, 1, -2, -2));
    }
}

void ViewportWidget::mousePressEvent(QMouseEvent* e)
{
    m_last = e->pos();
    emit activated(this);
}

void ViewportWidget::mouseMoveEvent(QMouseEvent* e)
{
    if (m_type == ViewType::Perspective && (e->buttons() & Qt::MiddleButton)) {
        m_yaw   += (e->pos().x() - m_last.x()) * 0.01;
        m_pitch  = std::clamp(m_pitch + (e->pos().y() - m_last.y()) * 0.01, 0.1, 1.5);
        update();
    }
    m_last = e->pos();
}

void ViewportWidget::wheelEvent(QWheelEvent* e)
{
    m_zoom = std::clamp(m_zoom * (e->angleDelta().y() > 0 ? 1.1 : 0.9), 0.2, 8.0);
    update();
}
