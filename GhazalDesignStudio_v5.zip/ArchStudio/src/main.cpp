#include <QApplication>
#include <QIcon>
#include <QMessageBox>
#include <QPushButton>
#include <QSettings>
#include <QTimer>
#include <functional>
#include <memory>
#include "Autosave.h"
#include "Document.h"
#include "MainWindow.h"
#include "Theme.h"
#include "Translations.h"

namespace {
QString trm(const char* s) { return QCoreApplication::translate("main", s); }

// After a crash: offer the newest unsaved snapshot.
void offerRecovery(QWidget* parent, Document& doc)
{
    const auto crashed = AutosaveManager::findCrashedSessions();
    if (crashed.isEmpty()) return;
    const auto& r = crashed.first();

    QMessageBox box(QMessageBox::Question, trm("Recover Work"),
                    trm("The program closed unexpectedly last time.\nDo you want to recover your unsaved work?"),
                    QMessageBox::NoButton, parent);
    auto* yes = box.addButton(trm("Recover"), QMessageBox::AcceptRole);
    box.addButton(trm("Discard"), QMessageBox::DestructiveRole);
    box.exec();

    if (box.clickedButton() == yes) {
        QString err;
        if (!doc.loadRecovered(r.snapshotPath, &err)) {       // keep the snapshot if recovery failed
            QMessageBox::warning(parent, trm("Error"), err);
            return;
        }
    }
    AutosaveManager::discard(r);
}
}

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    QCoreApplication::setOrganizationName("GhazalDesignStudio");
    QCoreApplication::setApplicationName("Ghazal Design Studio");
    QApplication::setStyle("Fusion");
    QApplication::setWindowIcon(QIcon(":/logo.png"));

    DictTranslator arabic;
    Document doc;                          // the project lives here, not in the window
    AutosaveManager autosave(doc);

    std::unique_ptr<MainWindow> win;
    std::function<void()> build;

    // (Re)creates the main window from the saved language/theme. The Document is untouched.
    build = [&] {
        QSettings s;
        const bool ar = s.value("language", "en").toString() == "ar";
        app.removeTranslator(&arabic);
        if (ar) app.installTranslator(&arabic);
        app.setLayoutDirection(ar ? Qt::RightToLeft : Qt::LeftToRight);
        app.setStyleSheet(Theme::styleSheet(Theme::fromName(s.value("theme", "dark").toString())));

        win = std::make_unique<MainWindow>(doc);
        if (!win->restoreGeometry(s.value("geometry").toByteArray()))
            win->resize(1500, 900);
        QObject::connect(win.get(), &MainWindow::uiSettingsChanged, [&] {
            QTimer::singleShot(0, [&] {
                QSettings().setValue("geometry", win->saveGeometry());
                auto old = std::move(win);
                build();                   // show the new window first
                old.reset();               // then destroy the old one
            });
        });
        win->show();
    };

    build();
    QTimer::singleShot(0, [&] {
        offerRecovery(win.get(), doc);
        autosave.start();
    });

    const int rc = app.exec();
    autosave.stop();                       // clean exit: remove snapshot and lock
    return rc;
}
