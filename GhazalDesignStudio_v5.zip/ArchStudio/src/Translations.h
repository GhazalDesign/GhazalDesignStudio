#pragma once
#include <QTranslator>

// Lightweight dictionary translator: English source text -> Arabic.
// No .ts/.qm pipeline needed; add new strings in Translations.cpp.
class DictTranslator : public QTranslator {
public:
    QString translate(const char* context, const char* source,
                      const char* disambiguation = nullptr, int n = -1) const override;
    bool isEmpty() const override { return false; }
};
