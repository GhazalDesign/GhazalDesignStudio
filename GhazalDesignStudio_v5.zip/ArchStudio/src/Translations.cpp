#include "Translations.h"
#include <QHash>

namespace {
struct Entry { const char* en; const char* ar; };
const Entry kTable[] = {
    // window / menus
    {"Ghazal Design Studio - Untitled", "Ghazal Design Studio - بدون عنوان"},
    {"Edit", "تحرير"}, {"Tools", "أدوات"}, {"Group", "مجموعة"}, {"Views", "عرض"},
    {"Create", "إنشاء"}, {"Modifiers", "معدّلات"}, {"Animation", "حركة"},
    {"Graph Editors", "محررات الرسوم البيانية"}, {"Rendering", "الريندر"},
    {"Drawings", "المخططات"}, {"Manufacturing", "التصنيع"}, {"Customize", "تخصيص"},
    {"Scripting", "السكربت"}, {"Help", "مساعدة"},
    {"Language", "اللغة"}, {"Theme", "المظهر"}, {"Dark", "غامق"}, {"Gray", "رمادي"}, {"Light", "فاتح"},
    // file menu
    {"File", "ملف"}, {"New Project", "مشروع جديد"}, {"New Window", "نافذة جديدة"},
    {"Open Project...", "فتح مشروع..."}, {"Open Recent", "المشاريع الأخيرة"},
    {"Save As...", "حفظ باسم..."}, {"Import...", "استيراد..."}, {"Export...", "تصدير..."},
    {"Exit", "خروج"}, {"(Empty)", "(فارغ)"}, {"Clear Recent Items", "مسح القائمة"},
    {"Open Project", "فتح مشروع"}, {"Save Project As", "حفظ المشروع باسم"},
    {"Import", "استيراد"}, {"Export", "تصدير"},
    {"Ghazal Project", "مشروع غزال"}, {"All Files", "كل الملفات"}, {"3D Models", "نماذج ثلاثية الأبعاد"},
    {"This command will be connected in the next phase.", "سيتم ربط هذا الأمر في المرحلة القادمة."},
    {"Selected: %1 (saving and loading will be connected in the next phase)",
     "تم الاختيار: %1 (الحفظ والفتح سيُربطان في المرحلة القادمة)"},
    // project / history
    {"Untitled", "بدون عنوان"}, {"Ghazal Design Studio", "Ghazal Design Studio"},
    {"Delete", "حذف"}, {"Undo %1", "تراجع عن %1"}, {"Redo %1", "إعادة %1"},
    {"Create %1", "إنشاء %1"}, {"Delete %1", "حذف %1"}, {"Rename %1", "إعادة تسمية %1"},
    {"Delete %1 Objects", "حذف %1 كائنات"}, {"%1 Objects Selected", "%1 كائنات محددة"},
    {"Command failed: %1", "فشل الأمر: %1"}, {"Saved", "تم الحفظ"}, {"Error", "خطأ"},
    {"Unsaved Changes", "تغييرات غير محفوظة"},
    {"Do you want to save changes to \"%1\"?", "هل تريد حفظ التغييرات في \"%1\"؟"},
    {"Don't Save", "عدم الحفظ"}, {"Cancel", "إلغاء"},
    {"Could not save the project:\n%1", "تعذّر حفظ المشروع:\n%1"},
    {"Could not open the project:\n%1", "تعذّر فتح المشروع:\n%1"},
    {"Recover Work", "استعادة العمل"}, {"Recover", "استعادة"}, {"Discard", "تجاهل"},
    {"The program closed unexpectedly last time.\nDo you want to recover your unsaved work?",
     "أُغلق البرنامج بشكل غير متوقع في المرة السابقة.\nهل تريد استعادة عملك غير المحفوظ؟"},
    // layers
    {"Layer", "الطبقة"}, {"Name", "الاسم"}, {"Visible", "ظاهر"}, {"Freeze", "تجميد"}, {"Lock", "قفل"},
    {"Color", "اللون"}, {"Current", "الحالية"},
    {"New Layer", "طبقة جديدة"}, {"Delete Layer", "حذف الطبقة"}, {"Set Current", "تعيين كحالية"},
    {"Move Selection Here", "نقل التحديد إلى الطبقة"},
    {"Create Layer %1", "إنشاء الطبقة %1"}, {"Delete Layer %1", "حذف الطبقة %1"},
    {"Edit Layer %1", "تعديل الطبقة %1"}, {"Move to Layer %1", "نقل إلى الطبقة %1"},
    {"The current layer is hidden, frozen or locked.", "الطبقة الحالية مخفية أو مجمّدة أو مقفلة."},
    // quick access
    {"Quick Access", "الوصول السريع"}, {"Application menu", "قائمة التطبيق"},
    {"New", "جديد"}, {"Open", "فتح"}, {"Save", "حفظ"}, {"Undo", "تراجع"}, {"Redo", "إعادة"},
    {"Workspace: Default", "مساحة العمل: افتراضية"}, {"Workspace: Cabinetry", "مساحة العمل: الخزائن"},
    {"Workspace: Rendering", "مساحة العمل: الريندر"},
    {"Type a keyword or phrase", "اكتب كلمة أو عبارة"}, {"Sign In", "تسجيل الدخول"},
    // main toolbar
    {"Main Toolbar", "شريط الأدوات"}, {"Link", "ربط"}, {"Unlink", "فك الربط"}, {"All", "الكل"},
    {"Geometry", "هندسة"}, {"Cabinets", "الخزائن"}, {"Lights", "إضاءة"}, {"Cameras", "كاميرات"},
    {"Select", "تحديد"}, {"Select by Name", "تحديد بالاسم"}, {"Rectangular Selection", "تحديد مستطيل"},
    {"Move", "نقل"}, {"Rotate", "تدوير"}, {"Scale", "تكبير/تصغير"},
    {"View", "العرض"}, {"World", "عالمي"}, {"Local", "محلي"}, {"Pivot", "نقطة الارتكاز"},
    {"3D Snap", "التقاط ثلاثي الأبعاد"}, {"Angle Snap", "التقاط الزاوية"},
    {"Percent Snap", "التقاط النسبة"}, {"Spinner Snap", "التقاط المؤشر"},
    {"Mirror", "مرآة"}, {"Align", "محاذاة"}, {"Layer Manager", "مدير الطبقات"},
    {"Material Editor", "محرر الخامات"}, {"Render Setup", "إعدادات الريندر"}, {"Quick Render", "ريندر سريع"},
    // ribbon
    {"Ribbon", "الشريط"}, {"Modeling", "النمذجة"}, {"Selection", "التحديد"}, {"Materials", "الخامات"},
    {"Extrude", "سحب"}, {"Bevel", "شطف"}, {"Boolean", "منطقي"}, {"Fillet", "تدوير الحواف"}, {"Shell", "قشرة"},
    {"Base Unit", "وحدة أرضية"}, {"Wall Unit", "وحدة جدارية"}, {"Tall Unit", "وحدة طويلة"},
    {"Drawer", "درج"}, {"Door", "باب"}, {"Cut List", "جدول القص"},
    {"Select All", "تحديد الكل"}, {"Invert", "عكس"}, {"Filter", "تصفية"},
    {"Wood", "خشب"}, {"Fabric", "قماش"}, {"Paint", "دهان"}, {"From Photo", "من صورة"},
    {"Plan", "مسقط"}, {"Elevation", "واجهة"}, {"Section", "مقطع"}, {"Dimension", "بُعد"},
    {"Render", "ريندر"}, {"Camera", "كاميرا"}, {"Client View", "عرض العميل"},
    // scene explorer
    {"Scene Explorer", "مستكشف المشهد"}, {"Display", "عرض"},
    {"Name (Sorted Ascending)", "الاسم (مرتب تصاعدياً)"}, {"Frozen", "مجمّد"},
    // command panel
    {"Command Panel", "لوحة الأوامر"}, {"Modify", "تعديل"}, {"Hierarchy", "التسلسل الهرمي"},
    {"Motion", "الحركة"}, {"Utilities", "أدوات مساعدة"}, {"Category", "الفئة"},
    {"Standard Primitives", "أشكال قياسية"}, {"Architectural", "معماري"}, {"Object Type", "نوع الكائن"},
    {"Wall", "جدار"}, {"Window", "نافذة"}, {"Stairs", "سلالم"}, {"Floor", "أرضية"}, {"Ceiling", "سقف"},
    {"Wardrobe", "دولاب"}, {"Shelf", "رف"},
    {"Box", "مكعب"}, {"Cone", "مخروط"}, {"Sphere", "كرة"}, {"GeoSphere", "كرة هندسية"},
    {"Cylinder", "أسطوانة"}, {"Tube", "أنبوب"}, {"Torus", "حلقة"}, {"Pyramid", "هرم"},
    {"Teapot", "إبريق"}, {"Plane", "سطح"}, {"Name and Color", "الاسم واللون"},
    // status bar
    {"Python / Script console", "كونسول بايثون / سكربت"}, {"None Selected", "لا يوجد تحديد"},
    {"Grid = 10.0", "الشبكة = 10.0"}, {"Auto Key", "مفاتيح تلقائية"}, {"Set Key", "تثبيت مفتاح"},
    {"Playback", "تشغيل"},
};
}

QString DictTranslator::translate(const char*, const char* source, const char*, int) const
{
    static const QHash<QString, QString> map = [] {
        QHash<QString, QString> m;
        for (const auto& e : kTable)
            m.insert(QString::fromUtf8(e.en), QString::fromUtf8(e.ar));
        return m;
    }();
    return map.value(QString::fromUtf8(source));   // empty -> Qt falls back to English
}
