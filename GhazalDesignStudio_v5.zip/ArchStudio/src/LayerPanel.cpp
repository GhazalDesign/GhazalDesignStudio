#include "LayerPanel.h"
#include <QColorDialog>
#include <QGridLayout>
#include <QHeaderView>
#include <QPushButton>
#include <QSignalBlocker>
#include <QTableWidget>
#include <QTimer>
#include <QVBoxLayout>

namespace {
enum Column { Current = 0, Name, Visible, Freeze, Lock, Color, ColumnCount };
}

LayerPanel::LayerPanel(Document& doc, QWidget* parent) : QWidget(parent), m_doc(doc)
{
    setObjectName("panel");
    auto* v = new QVBoxLayout(this);
    v->setContentsMargins(4, 4, 4, 4);

    m_table = new QTableWidget(0, ColumnCount);
    const struct { const char* symbol; const char* tip; } heads[ColumnCount] = {
        { "●", "Current" }, { "", "Name" }, { "👁", "Visible" }, { "❄", "Freeze" }, { "🔒", "Lock" }, { "■", "Color" } };
    for (int c = 0; c < ColumnCount; ++c) {
        auto* h = new QTableWidgetItem(QString::fromUtf8(heads[c].symbol));
        if (c == Name) h->setText(tr("Name"));
        h->setToolTip(tr(heads[c].tip));
        m_table->setHorizontalHeaderItem(c, h);
    }
    m_table->verticalHeader()->hide();
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->horizontalHeader()->setSectionResizeMode(Name, QHeaderView::Stretch);
    for (int c : { int(Current), int(Visible), int(Freeze), int(Lock), int(Color) })
        m_table->horizontalHeader()->setSectionResizeMode(c, QHeaderView::ResizeToContents);
    v->addWidget(m_table, 1);

    auto* grid = new QGridLayout;
    auto* bNew = new QPushButton(tr("New Layer"));
    auto* bDel = new QPushButton(tr("Delete Layer"));
    auto* bCur = new QPushButton(tr("Set Current"));
    auto* bAssign = new QPushButton(tr("Move Selection Here"));
    grid->addWidget(bNew, 0, 0);  grid->addWidget(bDel, 0, 1);
    grid->addWidget(bCur, 1, 0);  grid->addWidget(bAssign, 1, 1);
    v->addLayout(grid);

    connect(bNew, &QPushButton::clicked, this, [this] { m_doc.createLayer(); });
    connect(bDel, &QPushButton::clicked, this, [this] { if (const LayerId id = selectedLayer()) m_doc.deleteLayer(id); });
    connect(bCur, &QPushButton::clicked, this, [this] { if (const LayerId id = selectedLayer()) m_doc.setCurrentLayer(id); });
    connect(bAssign, &QPushButton::clicked, this, [this] { if (const LayerId id = selectedLayer()) m_doc.assignSelectionToLayer(id); });

    connect(m_table, &QTableWidget::itemChanged, this, [this](QTableWidgetItem* it) {
        auto* nameItem = m_table->item(it->row(), Name);
        if (!nameItem) return;
        const LayerId id = nameItem->data(Qt::UserRole).toUInt();
        if (!m_doc.scene().hasLayer(id)) return;
        Layer l = m_doc.scene().layer(id);
        switch (it->column()) {
        case Name:    l.name = it->text(); break;
        case Visible: l.visible = it->checkState() == Qt::Checked; break;
        case Freeze:  l.frozen = it->checkState() == Qt::Checked; break;
        case Lock:    l.locked = it->checkState() == Qt::Checked; break;
        default: return;
        }
        if (!m_doc.editLayer(l)) scheduleRefresh();          // rejected (e.g. empty name): restore
    });
    connect(m_table, &QTableWidget::cellDoubleClicked, this, [this](int row, int col) {
        auto* nameItem = m_table->item(row, Name);
        if (!nameItem) return;
        const LayerId id = nameItem->data(Qt::UserRole).toUInt();
        if (col == Current) {
            m_doc.setCurrentLayer(id);
        } else if (col == Color && m_doc.scene().hasLayer(id)) {
            Layer l = m_doc.scene().layer(id);
            const QColor c = QColorDialog::getColor(QColor(l.color), this, tr("Color"));
            if (c.isValid()) { l.color = c.name(); m_doc.editLayer(l); }
        }
    });

    connect(&m_doc, &Document::layersChanged, this, &LayerPanel::scheduleRefresh);
    refresh();
}

LayerId LayerPanel::selectedLayer() const
{
    const int row = m_table->currentRow();
    if (row < 0 || !m_table->item(row, Name)) return 0;
    return m_table->item(row, Name)->data(Qt::UserRole).toUInt();
}

// Deferred and coalesced, so the table is never rebuilt while it is still emitting a signal.
void LayerPanel::scheduleRefresh()
{
    if (m_pending) return;
    m_pending = true;
    QTimer::singleShot(0, this, [this] { m_pending = false; refresh(); });
}

void LayerPanel::refresh()
{
    QSignalBlocker block(m_table);
    const Scene& s = m_doc.scene();
    const LayerId keep = selectedLayer();
    m_table->setRowCount(int(s.layers().size()));

    auto checkItem = [](bool on) {
        auto* it = new QTableWidgetItem;
        it->setFlags(Qt::ItemIsEnabled | Qt::ItemIsUserCheckable);
        it->setCheckState(on ? Qt::Checked : Qt::Unchecked);
        return it;
    };

    int row = 0;
    for (const Layer& l : s.layers()) {
        auto* cur = new QTableWidgetItem(l.id == m_doc.currentLayer() ? QStringLiteral("●") : QString());
        cur->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);
        cur->setTextAlignment(Qt::AlignCenter);

        auto* name = new QTableWidgetItem(l.name);
        name->setData(Qt::UserRole, l.id);
        Qt::ItemFlags f = Qt::ItemIsEnabled | Qt::ItemIsSelectable;
        if (l.id != kDefaultLayer) f |= Qt::ItemIsEditable;      // the default layer keeps its name
        name->setFlags(f);

        auto* color = new QTableWidgetItem;
        color->setBackground(QColor(l.color));
        color->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable);

        m_table->setItem(row, Current, cur);
        m_table->setItem(row, Name, name);
        m_table->setItem(row, Visible, checkItem(l.visible));
        m_table->setItem(row, Freeze, checkItem(l.frozen));
        m_table->setItem(row, Lock, checkItem(l.locked));
        m_table->setItem(row, Color, color);
        if (l.id == keep) m_table->selectRow(row);
        ++row;
    }
}
