#include "MainWindow.h"
#include "ViewportWidget.h"
#include "Theme.h"
#include "LayerPanel.h"

#include <QAction>
#include <QActionGroup>
#include <QButtonGroup>
#include <QCloseEvent>
#include <QComboBox>
#include <QCoreApplication>
#include <QDir>
#include <QDockWidget>
#include <QDoubleValidator>
#include <QFileDialog>
#include <QFileInfo>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QIcon>
#include <QLabel>
#include <QLineEdit>
#include <QMap>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QSettings>
#include <QSignalBlocker>
#include <QSlider>
#include <QSplitter>
#include <QStackedWidget>
#include <QStatusBar>
#include <QTabBar>
#include <QTimer>
#include <QToolBar>
#include <QToolButton>
#include <QTreeWidget>
#include <QTreeWidgetItemIterator>
#include <QVBoxLayout>
#include <functional>

namespace {
QToolButton* makeButton(const QString& text, const QString& tip, bool checkable = false)
{
    auto* b = new QToolButton;
    b->setText(text);
    b->setToolTip(tip);
    b->setCheckable(checkable);
    b->setAutoRaise(false);
    return b;
}
}

MainWindow::MainWindow(Document& doc, QWidget* parent) : QMainWindow(parent), m_doc(doc)
{
    setDockNestingEnabled(true);

    buildMenus();                 // creates the actions the toolbars connect to
    buildQuickAccess();
    addToolBarBreak();
    buildMainToolbar();
    addToolBarBreak();
    buildRibbon();
    buildSceneExplorer();
    buildViewports();
    buildCommandPanel();
    buildLayerDock();
    buildTimeline();
    buildStatusBar();

    connect(&m_doc, &Document::sceneChanged, this, [this] { scheduleExplorerRefresh(); updateSelectionLabel(); });
    connect(&m_doc, &Document::selectionChanged, this, [this] { syncExplorerSelection(); updateSelectionLabel(); updateEditActions(); });
    connect(&m_doc, &Document::historyChanged, this, &MainWindow::updateEditActions);
    connect(&m_doc, &Document::titleChanged, this, &MainWindow::updateTitle);
    connect(&m_doc, &Document::errorOccurred, this, [this](const QString& m) { statusBar()->showMessage(m, 8000); });

    refreshExplorer();
    updateSelectionLabel();
    updateEditActions();
    updateTitle();
}

// ---------------------------------------------------------------- menus
void MainWindow::buildMenus()
{
    const QStringList names = { tr("File"), tr("Edit"), tr("Tools"), tr("Group"), tr("Views"),
        tr("Create"), tr("Modifiers"), tr("Animation"), tr("Graph Editors"),
        tr("Rendering"), tr("Drawings"), tr("Manufacturing"), tr("Customize"),
        tr("Scripting"), tr("Help") };
    for (const auto& n : names) {
        QMenu* menu = menuBar()->addMenu(n);
        if (n == tr("File")) buildFileMenu(menu);
        else if (n == tr("Edit")) buildEditMenu(menu);
        else if (n == tr("Customize")) buildCustomizeMenu(menu);
    }
}

void MainWindow::buildFileMenu(QMenu* menu)
{
    auto make = [menu](const QString& text, const QKeySequence& key) {
        QAction* a = menu->addAction(text);
        a->setShortcut(key);
        return a;
    };
    m_actNew       = make(tr("New Project"),     QKeySequence::New);
    m_actNewWindow = make(tr("New Window"),      QKeySequence("Ctrl+Shift+N"));
    menu->addSeparator();
    m_actOpen      = make(tr("Open Project..."), QKeySequence::Open);
    m_recentMenu   = menu->addMenu(tr("Open Recent"));
    menu->addSeparator();
    m_actSave      = make(tr("Save"),            QKeySequence::Save);
    m_actSaveAs    = make(tr("Save As..."),      QKeySequence::SaveAs);
    menu->addSeparator();
    m_actImport    = make(tr("Import..."),       QKeySequence("Ctrl+I"));
    m_actExport    = make(tr("Export..."),       QKeySequence("Ctrl+E"));
    menu->addSeparator();
    m_actExit      = make(tr("Exit"),            QKeySequence("Ctrl+Q"));

    connect(m_actNew,       &QAction::triggered, this, &MainWindow::newProject);
    connect(m_actNewWindow, &QAction::triggered, this, [] {
        QProcess::startDetached(QCoreApplication::applicationFilePath(), {});   // independent second window
    });
    connect(m_actOpen,   &QAction::triggered, this, &MainWindow::openProjectDialog);
    connect(m_actSave,   &QAction::triggered, this, [this] { saveProject(); });
    connect(m_actSaveAs, &QAction::triggered, this, [this] { saveProjectAs(); });
    connect(m_actImport, &QAction::triggered, this, &MainWindow::importDialog);
    connect(m_actExport, &QAction::triggered, this, &MainWindow::exportDialog);
    connect(m_actExit,   &QAction::triggered, this, &QWidget::close);
    updateRecentMenu();
}

void MainWindow::buildEditMenu(QMenu* menu)
{
    m_actUndo = menu->addAction(tr("Undo"));
    m_actUndo->setShortcut(QKeySequence::Undo);
    m_actRedo = menu->addAction(tr("Redo"));
    m_actRedo->setShortcut(QKeySequence::Redo);
    menu->addSeparator();
    m_actDelete = menu->addAction(tr("Delete"));
    m_actDelete->setShortcut(QKeySequence::Delete);

    connect(m_actUndo,   &QAction::triggered, this, [this] { m_doc.undo(); });
    connect(m_actRedo,   &QAction::triggered, this, [this] { m_doc.redo(); });
    connect(m_actDelete, &QAction::triggered, this, [this] { m_doc.deleteSelection(); });
}

// Language and theme choices. They are saved, then main() rebuilds the window.
void MainWindow::buildCustomizeMenu(QMenu* menu)
{
    auto addChoices = [this](QMenu* sub, const char* key, const QString& def,
                             const QList<QPair<QString, QString>>& items) {
        auto* group = new QActionGroup(this);
        const QString current = QSettings().value(key, def).toString();
        for (const auto& it : items) {
            QAction* a = sub->addAction(it.first);
            a->setCheckable(true);
            a->setChecked(it.second == current);
            group->addAction(a);
            const QString value = it.second;
            connect(a, &QAction::triggered, this, [this, key, value] {
                QSettings s;
                if (s.value(key).toString() == value) return;
                s.setValue(key, value);
                emit uiSettingsChanged();
            });
        }
    };
    addChoices(menu->addMenu(tr("Language")), "language", "en",
               { { "English", "en" }, { QString::fromUtf8("العربية"), "ar" } });
    addChoices(menu->addMenu(tr("Theme")), "theme", "dark",
               { { tr("Dark"), "dark" }, { tr("Gray"), "gray" }, { tr("Light"), "light" } });
}

// ---------------------------------------------------------------- quick access
void MainWindow::buildQuickAccess()
{
    auto* tb = addToolBar(tr("Quick Access"));
    tb->setMovable(false);
    auto* appBtn = makeButton("", tr("Application menu"));      // brand logo
    appBtn->setIcon(QIcon(":/logo.png"));
    appBtn->setIconSize(QSize(22, 22));
    tb->addWidget(appBtn);
    tb->addSeparator();

    auto quick = [&](const QString& label, QAction* act) {
        auto* b = makeButton(label, label);
        connect(b, &QToolButton::clicked, act, &QAction::trigger);
        tb->addWidget(b);
    };
    quick(tr("New"), m_actNew);   quick(tr("Open"), m_actOpen);   quick(tr("Save"), m_actSave);
    quick(tr("Undo"), m_actUndo); quick(tr("Redo"), m_actRedo);

    auto* ws = new QComboBox;
    ws->addItem(tr("Workspace: Default"));
    ws->addItem(tr("Workspace: Cabinetry"));
    ws->addItem(tr("Workspace: Rendering"));
    tb->addWidget(ws);

    auto* spacer = new QWidget;
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    tb->addWidget(spacer);

    auto* search = new QLineEdit;                       // Info Center
    search->setPlaceholderText(tr("Type a keyword or phrase"));
    search->setFixedWidth(200);
    tb->addWidget(search);
    tb->addWidget(makeButton(tr("Sign In"), tr("Sign In")));
    tb->addWidget(makeButton("?", tr("Help")));
}

// ---------------------------------------------------------------- main toolbar
void MainWindow::buildMainToolbar()
{
    auto* tb = addToolBar(tr("Main Toolbar"));
    tb->setMovable(false);

    auto add = [&](const QString& g, const QString& tip, bool chk = false) {
        auto* b = makeButton(g, tip, chk);
        tb->addWidget(b);
        return b;
    };

    connect(add("↶", tr("Undo")), &QToolButton::clicked, m_actUndo, &QAction::trigger);
    connect(add("↷", tr("Redo")), &QToolButton::clicked, m_actRedo, &QAction::trigger);
    tb->addSeparator();
    add("⛓", tr("Link")); add("✂", tr("Unlink"));
    tb->addSeparator();

    auto* filter = new QComboBox; filter->addItems({ tr("All"), tr("Geometry"), tr("Cabinets"), tr("Lights"), tr("Cameras") });
    tb->addWidget(filter);

    auto* sel = add("▣", tr("Select"), true);
    add("☰", tr("Select by Name"));
    add("▭", tr("Rectangular Selection"));
    tb->addSeparator();

    auto* tools = new QButtonGroup(this);
    tools->setExclusive(true);
    tools->addButton(sel);
    for (const auto& t : { QPair<QString,QString>{"✥", tr("Move")},
                           {"⟳", tr("Rotate")}, {"⤢", tr("Scale")} }) {
        auto* b = add(t.first, t.second, true);
        tools->addButton(b);
    }
    tb->addSeparator();

    auto* coord = new QComboBox; coord->addItems({ tr("View"), tr("World"), tr("Local") });
    tb->addWidget(coord);
    add("◎", tr("Pivot"));
    tb->addSeparator();
    add("3", tr("3D Snap"), true); add("∠", tr("Angle Snap"), true);
    add("%", tr("Percent Snap"), true); add("⇅", tr("Spinner Snap"), true);
    tb->addSeparator();
    add("⇋", tr("Mirror")); add("⫶", tr("Align"));
    connect(add("≡", tr("Layer Manager")), &QToolButton::clicked, this, [this] {
        if (m_layerDock) { m_layerDock->show(); m_layerDock->raise(); }
    });
    tb->addSeparator();
    add("◍", tr("Material Editor")); add("▶", tr("Render Setup"));
    add("⚡", tr("Quick Render"));
}

// ---------------------------------------------------------------- ribbon
void MainWindow::buildRibbon()
{
    auto* tb = addToolBar(tr("Ribbon"));
    tb->setMovable(false);

    auto* host = new QWidget; host->setObjectName("panel");
    auto* v = new QVBoxLayout(host);
    v->setContentsMargins(0, 0, 0, 0); v->setSpacing(0);

    auto* tabs = new QTabBar;
    tabs->setExpanding(false);
    auto* pages = new QStackedWidget;

    const QMap<QString, QStringList> content = {
        { tr("Modeling"),  { tr("Extrude"), tr("Bevel"), tr("Boolean"), tr("Fillet"), tr("Shell") } },
        { tr("Cabinets"),  { tr("Base Unit"), tr("Wall Unit"), tr("Tall Unit"), tr("Drawer"), tr("Door"), tr("Cut List") } },
        { tr("Selection"), { tr("Select All"), tr("Invert"), tr("Filter") } },
        { tr("Materials"), { tr("Wood"), tr("Fabric"), tr("Paint"), tr("From Photo") } },
        { tr("Drawings"),  { tr("Plan"), tr("Elevation"), tr("Section"), tr("Dimension") } },
        { tr("Rendering"), { tr("Render"), tr("Lights"), tr("Camera"), tr("Client View") } },
    };
    const QStringList order = { tr("Modeling"), tr("Cabinets"), tr("Selection"),
                                tr("Materials"), tr("Drawings"), tr("Rendering") };
    for (const auto& name : order) {
        tabs->addTab(name);
        auto* row = new QWidget;
        auto* h = new QHBoxLayout(row);
        h->setContentsMargins(2, 2, 2, 2);
        for (const auto& b : content.value(name)) h->addWidget(makeButton(b, b));
        h->addStretch();
        pages->addWidget(row);
    }
    connect(tabs, &QTabBar::currentChanged, pages, &QStackedWidget::setCurrentIndex);

    v->addWidget(tabs);
    v->addWidget(pages);
    host->setMinimumWidth(900);
    tb->addWidget(host);
}

// ---------------------------------------------------------------- scene explorer (left)
void MainWindow::buildSceneExplorer()
{
    auto* dock = new QDockWidget(tr("Scene Explorer"), this);
    dock->setFeatures(QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetFloatable);
    auto* w = new QWidget;
    auto* v = new QVBoxLayout(w);
    v->setContentsMargins(2, 2, 2, 2);

    auto* bar = new QHBoxLayout;
    for (const auto& s : { tr("Select"), tr("Display"), tr("Edit") }) bar->addWidget(new QLabel(s));
    bar->addStretch();
    v->addLayout(bar);
    v->addWidget(new QLineEdit);

    m_tree = new QTreeWidget;
    m_tree->setHeaderLabels({ tr("Name (Sorted Ascending)"), tr("Frozen"), tr("Layer") });
    m_tree->header()->setSectionResizeMode(0, QHeaderView::Stretch);
    m_tree->header()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    m_tree->header()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    m_tree->setSelectionMode(QAbstractItemView::ExtendedSelection);
    v->addWidget(m_tree, 1);

    connect(m_tree, &QTreeWidget::itemSelectionChanged, this, [this] {
        QVector<NodeId> ids;
        for (auto* it : m_tree->selectedItems()) ids.append(it->data(0, Qt::UserRole).toULongLong());
        m_doc.setSelection(ids);
    });
    connect(m_tree, &QTreeWidget::itemChanged, this, [this](QTreeWidgetItem* it, int col) {
        if (col != 0) { scheduleExplorerRefresh(); return; }       // only the name is editable
        const NodeId id = it->data(0, Qt::UserRole).toULongLong();
        if (!m_doc.renameNode(id, it->text(0))) scheduleExplorerRefresh();     // rejected: restore the old name
    });

    dock->setWidget(w);
    dock->setMinimumWidth(170);
    addDockWidget(Qt::LeftDockWidgetArea, dock);
}

// Rebuilding is deferred and coalesced: never while the tree is still emitting a signal.
void MainWindow::scheduleExplorerRefresh()
{
    if (m_refreshPending) return;
    m_refreshPending = true;
    QTimer::singleShot(0, this, [this] { m_refreshPending = false; refreshExplorer(); });
}

void MainWindow::refreshExplorer()
{
    QSignalBlocker block(m_tree);
    m_tree->clear();
    const QVector<NodeId> sel = m_doc.selection();

    std::function<void(NodeId, QTreeWidgetItem*)> addChildren = [&](NodeId id, QTreeWidgetItem* parentItem) {
        for (const NodeId c : m_doc.scene().node(id).children) {
            const SceneNode& n = m_doc.scene().node(c);
            auto* it = parentItem ? new QTreeWidgetItem(parentItem) : new QTreeWidgetItem(m_tree);
            it->setText(0, n.name);
            it->setText(1, n.frozen ? QStringLiteral("✓") : QString());
            it->setText(2, m_doc.scene().layerName(n.layer));
            it->setData(0, Qt::UserRole, QVariant::fromValue<qulonglong>(c));
            it->setFlags(it->flags() | Qt::ItemIsEditable);
            it->setSelected(sel.contains(c));
            addChildren(c, it);
        }
    };
    addChildren(Scene::Root, nullptr);
    m_tree->expandAll();
}

void MainWindow::syncExplorerSelection()
{
    QSignalBlocker block(m_tree);
    const QVector<NodeId>& sel = m_doc.selection();
    QTreeWidgetItemIterator it(m_tree);
    while (*it) {
        (*it)->setSelected(sel.contains((*it)->data(0, Qt::UserRole).toULongLong()));
        ++it;
    }
}

void MainWindow::updateSelectionLabel()
{
    const QVector<NodeId>& sel = m_doc.selection();
    if (sel.isEmpty()) m_selLabel->setText(tr("None Selected"));
    else if (sel.size() == 1) m_selLabel->setText(m_doc.scene().node(sel[0]).name);
    else m_selLabel->setText(tr("%1 Objects Selected").arg(sel.size()));
}

void MainWindow::updateEditActions()
{
    m_actUndo->setEnabled(m_doc.canUndo());
    m_actUndo->setText(m_doc.canUndo() ? tr("Undo %1").arg(m_doc.undoText()) : tr("Undo"));
    m_actRedo->setEnabled(m_doc.canRedo());
    m_actRedo->setText(m_doc.canRedo() ? tr("Redo %1").arg(m_doc.redoText()) : tr("Redo"));
    m_actDelete->setEnabled(!m_doc.selection().isEmpty());
}

void MainWindow::updateTitle()
{
    setWindowTitle(tr("Ghazal Design Studio") + " - " + m_doc.displayName() + "[*]");
    setWindowModified(m_doc.isDirty());
}

// ---------------------------------------------------------------- viewports (center)
void MainWindow::buildViewports()
{
    auto* top   = new ViewportWidget(ViewType::Top);
    auto* front = new ViewportWidget(ViewType::Front);
    auto* left  = new ViewportWidget(ViewType::Left);
    auto* persp = new ViewportWidget(ViewType::Perspective);
    m_viewports = { top, front, left, persp };

    // Nested splitters: user can resize each viewport, like in 3ds Max.
    auto* rows = new QSplitter(Qt::Vertical);
    auto* r1 = new QSplitter(Qt::Horizontal);
    auto* r2 = new QSplitter(Qt::Horizontal);
    r1->addWidget(top);  r1->addWidget(front);
    r2->addWidget(left); r2->addWidget(persp);
    rows->addWidget(r1); rows->addWidget(r2);
    connect(r1, &QSplitter::splitterMoved, this, [r1, r2] { r2->setSizes(r1->sizes()); });
    connect(r2, &QSplitter::splitterMoved, this, [r1, r2] { r1->setSizes(r2->sizes()); });

    for (auto* vp : m_viewports)
        connect(vp, &ViewportWidget::activated, this, &MainWindow::setActiveViewport);
    setActiveViewport(persp);
    rows->setLayoutDirection(Qt::LeftToRight);   // viewports are never mirrored in RTL
    const auto pal = Theme::palette(Theme::fromName(QSettings().value("theme", "dark").toString()));
    for (auto* vp : m_viewports) vp->applyTheme(pal);
    setCentralWidget(rows);
}

void MainWindow::setActiveViewport(ViewportWidget* v)
{
    for (auto* vp : m_viewports) vp->setActive(vp == v);
}

// ---------------------------------------------------------------- command panel (right)
void MainWindow::buildCommandPanel()
{
    auto* dock = new QDockWidget(tr("Command Panel"), this);
    m_commandDock = dock;
    dock->setFeatures(QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetFloatable);
    auto* w = new QWidget; w->setObjectName("panel");
    auto* v = new QVBoxLayout(w);
    v->setContentsMargins(4, 4, 4, 4);

    auto* tabsRow = new QHBoxLayout;
    auto* tabsGroup = new QButtonGroup(this);
    const QList<QPair<QString, QString>> tabs = {
        { "✚", tr("Create") }, { "◢", tr("Modify") }, { "⛓", tr("Hierarchy") },
        { "◎", tr("Motion") }, { "▣", tr("Display") }, { "🔧", tr("Utilities") } };
    for (int i = 0; i < tabs.size(); ++i) {
        auto* b = makeButton(tabs[i].first, tabs[i].second, true);
        b->setChecked(i == 0);
        tabsGroup->addButton(b);
        tabsRow->addWidget(b);
    }
    v->addLayout(tabsRow);

    auto* catRow = new QHBoxLayout;                       // object categories
    for (const auto& g : { "●", "◆", "☀", "▦", "≈", "✦" }) catRow->addWidget(makeButton(g, tr("Category")));
    v->addLayout(catRow);

    auto* combo = new QComboBox;
    combo->addItems({ tr("Standard Primitives"), tr("Architectural"), tr("Cabinets") });
    v->addWidget(combo);

    m_objectBox = new QGroupBox(tr("Object Type"));
    m_objectGrid = new QGridLayout(m_objectBox);
    v->addWidget(m_objectBox);
    fillObjectTypes(combo->currentIndex());
    connect(combo, &QComboBox::currentIndexChanged, this, &MainWindow::fillObjectTypes);

    auto* nameBox = new QGroupBox(tr("Name and Color"));
    auto* nh = new QHBoxLayout(nameBox);
    nh->addWidget(new QLineEdit, 1);
    auto* color = new QPushButton; color->setFixedSize(20, 20);
    color->setStyleSheet("background:#d02090;");
    nh->addWidget(color);
    v->addWidget(nameBox);

    v->addStretch();
    dock->setWidget(w);
    dock->setMinimumWidth(190);
    addDockWidget(Qt::RightDockWidgetArea, dock);
}

// Clicking a button creates a real scene object (undoable). Geometry arrives with the modeling phase.
void MainWindow::fillObjectTypes(int category)
{
    while (auto* item = m_objectGrid->takeAt(0)) {
        delete item->widget();
        delete item;
    }
    static const QList<QStringList> kinds = {
        { "Box", "Cone", "Sphere", "GeoSphere", "Cylinder", "Tube", "Torus", "Pyramid", "Teapot", "Plane" },
        { "Wall", "Door", "Window", "Stairs", "Floor", "Ceiling" },
        { "Base Unit", "Wall Unit", "Tall Unit", "Wardrobe", "Drawer", "Shelf" } };
    const QStringList keys = kinds.value(category);

    for (int i = 0; i < keys.size(); ++i) {
        const QString key = keys[i];                       // English type name stored in the project
        auto* b = new QPushButton(tr(key.toUtf8().constData()));
        connect(b, &QPushButton::clicked, this, [this, key] { m_doc.createNode(key); });
        m_objectGrid->addWidget(b, i / 2, i % 2);
    }
}

// ---------------------------------------------------------------- timeline (bottom)
void MainWindow::buildTimeline()
{
    auto* dock = new QDockWidget(this);
    dock->setTitleBarWidget(new QWidget);                 // hides the title bar
    dock->setFeatures(QDockWidget::NoDockWidgetFeatures);

    auto* w = new QWidget; w->setObjectName("panel");
    auto* h = new QHBoxLayout(w);
    h->setContentsMargins(2, 0, 2, 0);

    m_timeLabel = new QLabel("0 / 100");
    m_timeLabel->setMinimumWidth(50);
    m_timeSlider = new QSlider(Qt::Horizontal);
    m_timeSlider->setRange(0, 100);
    connect(m_timeSlider, &QSlider::valueChanged, this,
            [this](int f) { m_timeLabel->setText(QString("%1 / 100").arg(f)); });
    h->addWidget(m_timeLabel);
    h->addWidget(m_timeSlider, 1);

    dock->setWidget(w);
    addDockWidget(Qt::BottomDockWidgetArea, dock);
}

// ---------------------------------------------------------------- status bar
void MainWindow::buildStatusBar()
{
    auto* sb = statusBar();

    auto* console = new QLineEdit;                        // script console
    console->setPlaceholderText(tr("Python / Script console"));
    console->setFixedWidth(160);
    sb->addWidget(console);

    m_selLabel = new QLabel;
    sb->addWidget(m_selLabel, 1);

    for (const auto& axis : { "X", "Y", "Z" }) {
        sb->addPermanentWidget(new QLabel(axis));
        auto* f = new QLineEdit("0.0");           // placeholder until transform editing is wired
        auto* val = new QDoubleValidator(-1e9, 1e9, 3, f);
        val->setLocale(QLocale::c());
        f->setValidator(val);
        f->setFixedWidth(84);
        sb->addPermanentWidget(f);
    }
    sb->addPermanentWidget(new QLabel(tr("Grid = 10.0")));
    sb->addPermanentWidget(makeButton(tr("Auto Key"), tr("Auto Key"), true));
    sb->addPermanentWidget(makeButton(tr("Set Key"), tr("Set Key")));
    for (const auto& g : { "⏮", "◀", "▶", "▶▶", "⏭" })
        sb->addPermanentWidget(makeButton(g, tr("Playback")));
}

// ---------------------------------------------------------------- file commands
void MainWindow::showError(const QString& message)
{
    QMessageBox::critical(this, tr("Error"), message);
}

bool MainWindow::maybeSave()
{
    if (!m_doc.isDirty()) return true;
    QMessageBox box(QMessageBox::Warning, tr("Unsaved Changes"),
                    tr("Do you want to save changes to \"%1\"?").arg(m_doc.displayName()),
                    QMessageBox::NoButton, this);
    auto* save = box.addButton(tr("Save"), QMessageBox::AcceptRole);
    auto* discard = box.addButton(tr("Don't Save"), QMessageBox::DestructiveRole);
    box.addButton(tr("Cancel"), QMessageBox::RejectRole);
    box.exec();
    if (box.clickedButton() == save) return saveProject();
    return box.clickedButton() == discard;               // Cancel / Esc -> false
}

bool MainWindow::saveProject()
{
    if (m_doc.filePath().isEmpty()) return saveProjectAs();
    QString err;
    if (!m_doc.save(m_doc.filePath(), &err)) {
        showError(tr("Could not save the project:\n%1").arg(err));
        return false;
    }
    statusBar()->showMessage(tr("Saved"), 3000);
    return true;
}

bool MainWindow::saveProjectAs()
{
    const QString filter = tr("Ghazal Project") + " (*.gds)";
    QString path = QFileDialog::getSaveFileName(this, tr("Save Project As"), QString(), filter);
    if (path.isEmpty()) return false;
    if (QFileInfo(path).suffix().isEmpty()) path += ".gds";
    QString err;
    if (!m_doc.save(path, &err)) {
        showError(tr("Could not save the project:\n%1").arg(err));
        return false;
    }
    addRecent(path);
    statusBar()->showMessage(tr("Saved"), 3000);
    return true;
}

void MainWindow::newProject()
{
    if (maybeSave()) m_doc.newProject();
}

void MainWindow::openProjectDialog()
{
    const QString filter = tr("Ghazal Project") + " (*.gds);;" + tr("All Files") + " (*)";
    const QString path = QFileDialog::getOpenFileName(this, tr("Open Project"), QString(), filter);
    if (!path.isEmpty()) openProject(path);
}

void MainWindow::openProject(const QString& path)
{
    if (!maybeSave()) return;
    QString err;
    if (!m_doc.load(path, &err)) {                        // the current project stays open
        showError(tr("Could not open the project:\n%1").arg(err));
        return;
    }
    addRecent(path);
}

void MainWindow::addRecent(const QString& path)
{
    QSettings s;
    QStringList recent = s.value("recentFiles").toStringList();
    recent.removeAll(path);
    recent.prepend(path);
    while (recent.size() > 8) recent.removeLast();
    s.setValue("recentFiles", recent);
    updateRecentMenu();
}

void MainWindow::updateRecentMenu()
{
    m_recentMenu->clear();
    const QStringList recent = QSettings().value("recentFiles").toStringList();
    if (recent.isEmpty()) {
        m_recentMenu->addAction(tr("(Empty)"))->setEnabled(false);
        return;
    }
    for (const QString& path : recent) {
        QAction* a = m_recentMenu->addAction(QFileInfo(path).fileName());
        a->setToolTip(QDir::toNativeSeparators(path));
        connect(a, &QAction::triggered, this, [this, path] { openProject(path); });
    }
    m_recentMenu->addSeparator();
    connect(m_recentMenu->addAction(tr("Clear Recent Items")), &QAction::triggered, this, [this] {
        QSettings().remove("recentFiles");
        updateRecentMenu();
    });
}

void MainWindow::importDialog()
{
    const QString filter = tr("3D Models") + " (*.obj *.fbx *.stl *.step *.stp *.iges *.igs *.dxf *.dwg *.skp *.ifc);;"
                         + tr("All Files") + " (*)";
    const QString path = QFileDialog::getOpenFileName(this, tr("Import"), QString(), filter);
    if (!path.isEmpty()) notePending(path);
}

void MainWindow::exportDialog()
{
    const QString path = QFileDialog::getSaveFileName(this, tr("Export"), QString(),
                                                      "PDF (*.pdf);;DXF (*.dxf);;OBJ (*.obj);;STEP (*.step)");
    if (!path.isEmpty()) notePending(path);
}

void MainWindow::notePending(const QString& path)
{
    statusBar()->showMessage(
        tr("Selected: %1 (saving and loading will be connected in the next phase)")
            .arg(QDir::toNativeSeparators(path)), 8000);
}

void MainWindow::closeEvent(QCloseEvent* e)
{
    if (!maybeSave()) { e->ignore(); return; }
    QSettings().setValue("geometry", saveGeometry());
    QMainWindow::closeEvent(e);
}

// ---------------------------------------------------------------- layer manager (tabbed with the command panel)
void MainWindow::buildLayerDock()
{
    m_layerDock = new QDockWidget(tr("Layer Manager"), this);
    m_layerDock->setFeatures(QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetFloatable);
    m_layerDock->setWidget(new LayerPanel(m_doc));
    addDockWidget(Qt::RightDockWidgetArea, m_layerDock);
    if (m_commandDock) {
        tabifyDockWidget(m_commandDock, m_layerDock);
        m_commandDock->raise();
    }
}
