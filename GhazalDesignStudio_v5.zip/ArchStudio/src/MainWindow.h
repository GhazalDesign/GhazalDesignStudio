#pragma once
#include <QList>
#include <QMainWindow>
#include "Document.h"

class ViewportWidget;
class QGridLayout;
class QGroupBox;
class QSlider;
class QLabel;
class QMenu;
class QDockWidget;
class QAction;
class QCloseEvent;
class QTreeWidget;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(Document& doc, QWidget* parent = nullptr);

signals:
    void uiSettingsChanged();   // language or theme changed -> main() rebuilds the window

protected:
    void closeEvent(QCloseEvent* e) override;

private:
    void buildMenus();
    void buildFileMenu(QMenu* menu);
    void buildEditMenu(QMenu* menu);
    void buildCustomizeMenu(QMenu* menu);
    void buildQuickAccess();
    void buildMainToolbar();
    void buildRibbon();
    void buildSceneExplorer();
    void buildViewports();
    void buildCommandPanel();
    void buildLayerDock();
    void buildTimeline();
    void buildStatusBar();

    void fillObjectTypes(int category);
    void setActiveViewport(ViewportWidget* v);

    // document -> UI
    void scheduleExplorerRefresh();
    void refreshExplorer();
    void syncExplorerSelection();
    void updateSelectionLabel();
    void updateEditActions();
    void updateTitle();

    // file commands
    bool maybeSave();
    bool saveProject();
    bool saveProjectAs();
    void newProject();
    void openProjectDialog();
    void openProject(const QString& path);
    void addRecent(const QString& path);
    void updateRecentMenu();
    void importDialog();
    void exportDialog();
    void notePending(const QString& path);
    void showError(const QString& message);

    Document& m_doc;
    QList<ViewportWidget*> m_viewports;
    QTreeWidget* m_tree = nullptr;
    QDockWidget* m_commandDock = nullptr;
    QDockWidget* m_layerDock = nullptr;
    bool m_refreshPending = false;
    QMenu* m_recentMenu = nullptr;
    QAction *m_actNew = nullptr, *m_actNewWindow = nullptr, *m_actOpen = nullptr, *m_actSave = nullptr,
            *m_actSaveAs = nullptr, *m_actImport = nullptr, *m_actExport = nullptr, *m_actExit = nullptr,
            *m_actUndo = nullptr, *m_actRedo = nullptr, *m_actDelete = nullptr;
    QGridLayout* m_objectGrid = nullptr;
    QGroupBox*   m_objectBox = nullptr;
    QSlider*     m_timeSlider = nullptr;
    QLabel*      m_timeLabel = nullptr;
    QLabel*      m_selLabel = nullptr;
};
