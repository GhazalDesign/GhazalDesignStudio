#include "Scene.h"
#include <QJsonArray>
#include <QSet>
#include <algorithm>
#include <stdexcept>

namespace {
QJsonArray toArr(const Vec3& v) { return { v.x, v.y, v.z }; }
Vec3 fromArr(const QJsonValue& val, Vec3 def)
{
    const QJsonArray a = val.toArray();
    return a.size() == 3 ? Vec3{ a[0].toDouble(), a[1].toDouble(), a[2].toDouble() } : def;
}
}

QJsonObject SceneNode::toJson() const
{
    QJsonObject o;
    o["id"] = static_cast<double>(id);
    o["parent"] = static_cast<double>(parent);
    o["type"] = type;
    o["name"] = name;
    o["position"] = toArr(position);
    o["rotation"] = toArr(rotation);
    o["scale"] = toArr(scale);
    o["visible"] = visible;
    o["frozen"] = frozen;
    o["layer"] = static_cast<double>(layer);
    if (!params.isEmpty()) o["params"] = params;
    return o;
}

SceneNode SceneNode::fromJson(const QJsonObject& o)
{
    SceneNode n;
    n.id = static_cast<NodeId>(o.value("id").toDouble());
    n.parent = static_cast<NodeId>(o.value("parent").toDouble());
    if (n.id == kNoNode) throw std::runtime_error("node without id");
    n.type = o.value("type").toString();
    n.name = o.value("name").toString();
    n.position = fromArr(o.value("position"), Vec3{});
    n.rotation = fromArr(o.value("rotation"), Vec3{});
    n.scale = fromArr(o.value("scale"), Vec3{ 1, 1, 1 });
    n.visible = o.value("visible").toBool(true);
    n.frozen = o.value("frozen").toBool(false);
    n.layer = static_cast<LayerId>(o.value("layer").toInt(int(kDefaultLayer)));
    n.params = o.value("params").toObject();
    return n;
}

Scene::Scene() { reset(); }

void Scene::reset()
{
    m_nodes.clear();
    m_next = Root + 1;
    SceneNode r;
    r.id = Root;
    r.type = "Root";
    r.name = "Scene";
    m_nodes.insert(Root, r);

    Layer def;
    def.id = kDefaultLayer;
    def.name = "0";
    m_layers.clear();
    m_layers.append(def);
    m_nextLayer = kDefaultLayer + 1;
}

const SceneNode& Scene::node(NodeId id) const
{
    const auto it = m_nodes.constFind(id);
    if (it == m_nodes.constEnd()) throw std::out_of_range("unknown node id");
    return it.value();
}

SceneNode& Scene::node(NodeId id)
{
    const auto it = m_nodes.find(id);
    if (it == m_nodes.end()) throw std::out_of_range("unknown node id");
    return it.value();
}

void Scene::insert(SceneNode n, int index)
{
    if (n.id == kNoNode || m_nodes.contains(n.id)) throw std::invalid_argument("duplicate or empty node id");
    if (!m_nodes.contains(n.parent)) throw std::invalid_argument("parent does not exist");
    n.children.clear();
    if (!hasLayer(n.layer)) n.layer = kDefaultLayer;
    const NodeId id = n.id, parent = n.parent;
    m_nodes.insert(id, std::move(n));
    QVector<NodeId>& kids = node(parent).children;    // fetched after insert: the hash may have rehashed
    if (index < 0 || index > kids.size()) kids.append(id); else kids.insert(index, id);
    if (id >= m_next) m_next = id + 1;
}

void Scene::removeSubtree(NodeId id)
{
    if (id == Root) throw std::invalid_argument("the scene root cannot be removed");
    node(node(id).parent).children.removeOne(id);
    QVector<NodeId> stack{ id };
    while (!stack.isEmpty()) {
        const NodeId cur = stack.takeLast();
        const QVector<NodeId> kids = node(cur).children;
        stack += kids;
        m_nodes.remove(cur);
    }
}

QVector<SceneNode> Scene::collectSubtree(NodeId id) const
{
    QVector<SceneNode> out;
    QVector<NodeId> stack{ id };
    while (!stack.isEmpty()) {
        const SceneNode& n = node(stack.takeLast());
        out.append(n);
        for (int i = int(n.children.size()) - 1; i >= 0; --i) stack.append(n.children[i]);
    }
    return out;
}

int Scene::indexInParent(NodeId id) const
{
    return int(node(node(id).parent).children.indexOf(id));
}

QString Scene::uniqueName(const QString& base) const
{
    QSet<QString> used;
    for (const SceneNode& n : m_nodes) used.insert(n.name);
    for (int i = 1;; ++i) {
        const QString c = QStringLiteral("%1%2").arg(base).arg(i, 3, 10, QLatin1Char('0'));
        if (!used.contains(c)) return c;
    }
}

QJsonObject Scene::toJson() const
{
    QJsonArray arr;
    for (const SceneNode& n : collectSubtree(Root)) arr.append(n.toJson());
    QJsonObject o;
    o["nextId"] = static_cast<double>(m_next);
    o["nodes"] = arr;
    QJsonArray la;
    for (const Layer& l : m_layers) la.append(l.toJson());
    o["layers"] = la;
    o["nextLayerId"] = static_cast<double>(m_nextLayer);
    return o;
}

void Scene::fromJson(const QJsonObject& o)
{
    const QJsonArray arr = o.value("nodes").toArray();
    if (arr.isEmpty()) throw std::runtime_error("scene has no nodes");

    QHash<NodeId, SceneNode> nodes;
    QVector<NodeId> order;
    NodeId maxId = Root;
    for (const QJsonValue& v : arr) {
        SceneNode n = SceneNode::fromJson(v.toObject());
        if (nodes.contains(n.id)) throw std::runtime_error("duplicate node id");
        order.append(n.id);
        maxId = std::max(maxId, n.id);
        nodes.insert(n.id, std::move(n));
    }
    if (!nodes.contains(Root) || nodes.value(Root).parent != kNoNode) throw std::runtime_error("missing scene root");

    for (const NodeId id : order) {
        if (id == Root) continue;
        const auto pit = nodes.find(nodes.value(id).parent);
        if (pit == nodes.end()) throw std::runtime_error("node refers to an unknown parent");
        pit.value().children.append(id);
    }
    // every node must be reachable from the root (rejects cycles / detached nodes)
    int visited = 0;
    QVector<NodeId> stack{ Root };
    while (!stack.isEmpty()) {
        const NodeId cur = stack.takeLast();
        ++visited;
        stack += nodes.value(cur).children;
        if (visited > nodes.size()) throw std::runtime_error("cyclic node hierarchy");
    }
    if (visited != nodes.size()) throw std::runtime_error("detached nodes in hierarchy");

    // layers (older files without them get just the default layer)
    QVector<Layer> layers;
    LayerId maxLayer = kDefaultLayer;
    for (const QJsonValue& v : o.value("layers").toArray()) {
        Layer l = Layer::fromJson(v.toObject());
        for (const Layer& other : layers)
            if (other.id == l.id) throw std::runtime_error("duplicate layer id");
        maxLayer = std::max(maxLayer, l.id);
        layers.append(l);
    }
    bool hasDefault = false;
    for (const Layer& l : layers) hasDefault = hasDefault || l.id == kDefaultLayer;
    if (!hasDefault) {
        Layer def;
        def.id = kDefaultLayer;
        def.name = "0";
        layers.prepend(def);
    }
    for (auto it = nodes.begin(); it != nodes.end(); ++it) {       // unknown layer -> default
        bool known = false;
        for (const Layer& l : layers) known = known || l.id == it.value().layer;
        if (!known) it.value().layer = kDefaultLayer;
    }

    m_nodes = std::move(nodes);
    m_next = std::max(static_cast<NodeId>(o.value("nextId").toDouble()), maxId + 1);
    m_layers = std::move(layers);
    m_nextLayer = std::max(static_cast<LayerId>(o.value("nextLayerId").toDouble()), maxLayer + 1);
}

// ---------------------------------------------------------------- layers
QJsonObject Layer::toJson() const
{
    QJsonObject o;
    o["id"] = static_cast<double>(id);
    o["name"] = name;
    o["color"] = color;
    o["visible"] = visible;
    o["frozen"] = frozen;
    o["locked"] = locked;
    return o;
}

Layer Layer::fromJson(const QJsonObject& o)
{
    Layer l;
    l.id = static_cast<LayerId>(o.value("id").toInt(0));
    if (l.id == 0) throw std::runtime_error("layer without id");
    l.name = o.value("name").toString();
    l.color = o.value("color").toString("#c8c8c8");
    l.visible = o.value("visible").toBool(true);
    l.frozen = o.value("frozen").toBool(false);
    l.locked = o.value("locked").toBool(false);
    return l;
}

bool Scene::hasLayer(LayerId id) const { return layerIndex(id) >= 0; }

int Scene::layerIndex(LayerId id) const
{
    for (int i = 0; i < m_layers.size(); ++i)
        if (m_layers[i].id == id) return i;
    return -1;
}

const Layer& Scene::layer(LayerId id) const
{
    const int i = layerIndex(id);
    if (i < 0) throw std::out_of_range("unknown layer id");
    return m_layers[i];
}

Layer& Scene::layer(LayerId id)
{
    const int i = layerIndex(id);
    if (i < 0) throw std::out_of_range("unknown layer id");
    return m_layers[i];
}

QString Scene::layerName(LayerId id) const { return hasLayer(id) ? layer(id).name : QStringLiteral("?"); }

void Scene::insertLayer(Layer l, int index)
{
    if (l.id == 0 || hasLayer(l.id)) throw std::invalid_argument("duplicate or empty layer id");
    const LayerId id = l.id;
    if (index < 0 || index > m_layers.size()) m_layers.append(std::move(l)); else m_layers.insert(index, std::move(l));
    if (id >= m_nextLayer) m_nextLayer = id + 1;
}

void Scene::removeLayer(LayerId id)
{
    if (id == kDefaultLayer) throw std::invalid_argument("the default layer cannot be removed");
    const int i = layerIndex(id);
    if (i < 0) throw std::out_of_range("unknown layer id");
    for (auto it = m_nodes.begin(); it != m_nodes.end(); ++it)
        if (it.value().layer == id) it.value().layer = kDefaultLayer;
    m_layers.removeAt(i);
}

QVector<NodeId> Scene::nodesOnLayer(LayerId id) const
{
    QVector<NodeId> out;
    for (const SceneNode& n : m_nodes)
        if (n.layer == id && n.id != Root) out.append(n.id);
    return out;
}

QString Scene::uniqueLayerName(const QString& base) const
{
    QSet<QString> used;
    for (const Layer& l : m_layers) used.insert(l.name);
    for (int i = 1;; ++i) {
        const QString c = QStringLiteral("%1%2").arg(base).arg(i, 3, 10, QLatin1Char('0'));
        if (!used.contains(c)) return c;
    }
}

bool Scene::layerUsable(LayerId id) const
{
    if (!hasLayer(id)) return false;
    const Layer& l = layer(id);
    return l.visible && !l.frozen && !l.locked;
}

bool Scene::isSelectable(NodeId id) const
{
    return id != Root && contains(id) && layerUsable(node(id).layer);
}
