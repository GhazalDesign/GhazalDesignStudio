#pragma once
#include <QObject>
#include <QVector>
#include <memory>
#include "Scene.h"
#include "UndoStack.h"

// The open project: scene + history + selection + file state.
// Lives outside MainWindow, so changing language/theme (which rebuilds the window) loses nothing.
// All edits go through commands, so every edit is undoable.
class Document : public QObject {
    Q_OBJECT
public:
    explicit Document(QObject* parent = nullptr);

    const Scene& scene() const { return m_scene; }

    // editing
    NodeId createNode(const QString& type, NodeId parent = Scene::Root);   // kNoNode on failure
    bool deleteSelection();
    bool renameNode(NodeId id, const QString& newName);

    // layers
    LayerId currentLayer() const { return m_currentLayer; }      // new objects are created on it
    void setCurrentLayer(LayerId id);
    LayerId createLayer();                                        // 0 on failure
    bool deleteLayer(LayerId id);
    bool editLayer(const Layer& changed);                         // rename / colour / visible / frozen / locked
    bool assignSelectionToLayer(LayerId id);
    bool undo();
    bool redo();
    bool canUndo() const { return m_undo.canUndo(); }
    bool canRedo() const { return m_undo.canRedo(); }
    QString undoText() const { return m_undo.undoText(); }
    QString redoText() const { return m_undo.redoText(); }

    // selection (not part of undo history, like 3ds Max)
    const QVector<NodeId>& selection() const { return m_selection; }
    void setSelection(QVector<NodeId> ids);

    // file state
    QString filePath() const { return m_path; }
    QString displayName() const;
    bool isDirty() const { return m_forceDirty || !m_undo.isClean(); }
    quint64 revision() const { return m_revision; }

    void newProject();
    bool load(const QString& path, QString* error);
    bool loadRecovered(const QString& snapshotPath, QString* error);
    bool save(const QString& path, QString* error);
    bool saveSnapshot(const QString& snapshotPath, QString* error) const;   // autosave: no state change

signals:
    void sceneChanged();
    void layersChanged();
    void selectionChanged();
    void historyChanged();
    void titleChanged();          // name or dirty state changed
    void errorOccurred(const QString& message);

private:
    bool execute(std::unique_ptr<Command> cmd);
    void afterChange();
    void notifyDirty();
    void failHistory(const std::exception& e);

    Scene m_scene;
    UndoStack m_undo;
    QVector<NodeId> m_selection;
    QString m_path;
    bool m_forceDirty = false;       // recovered work counts as unsaved
    bool m_lastDirty = false;
    quint64 m_revision = 0;
    LayerId m_currentLayer = kDefaultLayer;
};
