#include "Autosave.h"
#include "ProjectFile.h"
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QStandardPaths>
#include <QUuid>
#include <algorithm>

QString AutosaveManager::autosaveDir()
{
    return QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation) + "/autosave";
}

AutosaveManager::AutosaveManager(Document& doc, QObject* parent) : QObject(parent), m_doc(doc)
{
    m_dir = autosaveDir();
    m_id = QUuid::createUuid().toString(QUuid::WithoutBraces);
    m_timer.setInterval(5000);
    connect(&m_timer, &QTimer::timeout, this, &AutosaveManager::tick);
}

void AutosaveManager::start()
{
    QDir().mkpath(m_dir);
    m_lock = std::make_unique<QLockFile>(m_dir + "/" + m_id + ".lock");
    m_lock->setStaleLockTime(0);        // staleness = owner process is gone, never "too old"
    m_lock->tryLock(0);
    m_timer.start();
}

void AutosaveManager::stop()
{
    m_timer.stop();
    QFile::remove(snapshotPath());
    if (m_lock) m_lock->unlock();
}

void AutosaveManager::tick()
{
    const quint64 rev = m_doc.revision();
    const bool dirty = m_doc.isDirty();
    if (rev == m_lastRevision && dirty == m_lastDirty) return;     // nothing new

    if (!dirty) {                                                  // saved: the snapshot is obsolete
        QFile::remove(snapshotPath());
    } else {
        QString err;
        if (!m_doc.saveSnapshot(snapshotPath(), &err)) return;     // try again on the next tick
    }
    m_lastRevision = rev;
    m_lastDirty = dirty;
}

QList<AutosaveManager::Recoverable> AutosaveManager::findCrashedSessions()
{
    QList<Recoverable> out;
    const QString dir = autosaveDir();
    for (const QFileInfo& fi : QDir(dir).entryInfoList({ "*.lock" }, QDir::Files)) {
        QLockFile lock(fi.absoluteFilePath());
        lock.setStaleLockTime(0);
        if (!lock.tryLock(0)) continue;          // still held by a running instance
        lock.unlock();                            // owner is gone: crashed session, lock file removed

        const QString snap = dir + "/" + fi.completeBaseName() + ".gds";
        if (!QFileInfo::exists(snap)) continue;
        Scene s;
        QJsonObject meta;
        QString err;
        if (!ProjectFile::read(snap, s, &err, &meta)) { QFile::remove(snap); continue; }
        out.append({ snap, meta.value("originalPath").toString(), QFileInfo(snap).lastModified() });
    }
    std::sort(out.begin(), out.end(), [](const Recoverable& a, const Recoverable& b) { return a.time > b.time; });
    return out;
}

void AutosaveManager::discard(const Recoverable& r) { QFile::remove(r.snapshotPath); }
