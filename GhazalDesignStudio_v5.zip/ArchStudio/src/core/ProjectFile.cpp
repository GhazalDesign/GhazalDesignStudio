#include "ProjectFile.h"
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QSaveFile>
#include <exception>

namespace {
void setError(QString* e, const QString& m) { if (e) *e = m; }
const char* kFormat = "GhazalDesignStudio";
}

bool ProjectFile::write(const QString& path, const Scene& scene, QString* error,
                        const QJsonObject& meta, bool keepBackup)
{
    QJsonObject root;
    root["format"] = QString::fromLatin1(kFormat);
    root["version"] = kVersion;
    root["meta"] = meta;
    root["scene"] = scene.toJson();
    const QByteArray bytes = QJsonDocument(root).toJson(QJsonDocument::Indented);

    QDir().mkpath(QFileInfo(path).absolutePath());
    if (keepBackup && QFile::exists(path)) {
        QFile::remove(path + ".bak");
        QFile::copy(path, path + ".bak");
    }

    QSaveFile f(path);
    if (!f.open(QIODevice::WriteOnly)) { setError(error, f.errorString()); return false; }
    if (f.write(bytes) != bytes.size()) { setError(error, f.errorString()); f.cancelWriting(); return false; }
    if (!f.commit()) { setError(error, f.errorString()); return false; }
    return true;
}

bool ProjectFile::read(const QString& path, Scene& scene, QString* error, QJsonObject* meta)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) { setError(error, f.errorString()); return false; }

    QJsonParseError pe;
    const QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &pe);
    if (pe.error != QJsonParseError::NoError || !doc.isObject()) {
        setError(error, "not a valid project file");
        return false;
    }
    const QJsonObject root = doc.object();
    if (root.value("format").toString() != QLatin1String(kFormat)) {
        setError(error, "not a Ghazal Design Studio project");
        return false;
    }
    const int version = root.value("version").toInt(0);
    if (version < 1) { setError(error, "unknown file version"); return false; }
    if (version > kVersion) {
        setError(error, "this project was created by a newer version of the program");
        return false;
    }
    // Migrations go here, e.g.: if (version == 1) migrateV1toV2(root);

    Scene tmp;
    try {
        tmp.fromJson(root.value("scene").toObject());
    } catch (const std::exception& e) {
        setError(error, QString("damaged project: %1").arg(QString::fromUtf8(e.what())));
        return false;
    }
    scene = std::move(tmp);
    if (meta) *meta = root.value("meta").toObject();
    return true;
}
