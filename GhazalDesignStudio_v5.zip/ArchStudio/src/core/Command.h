#pragma once
#include "Scene.h"

// Every change to the scene is a Command. Commands work on the Scene only (never on UI),
// so they can be tested alone. redo() must be atomic: it either fully applies or throws
// without having changed anything.
class Command {
public:
    virtual ~Command() = default;
    virtual QString text() const = 0;       // shown as "Undo <text>"
    virtual void redo(Scene& scene) = 0;
    virtual void undo(Scene& scene) = 0;
};
