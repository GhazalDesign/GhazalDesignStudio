#pragma once
#include "Scene.h"

// Project file (.gds). Today: versioned JSON, written atomically.
// The rest of the program only uses read()/write(), so the container can later become
// SQLite or a compressed archive without touching anything else.
namespace ProjectFile {

constexpr int kVersion = 1;

// Atomic: writes to a temp file and renames it over the target (QSaveFile), so a crash or
// power loss in the middle can never leave a half-written project. Keeps "<file>.bak".
bool write(const QString& path, const Scene& scene, QString* error,
           const QJsonObject& meta = {}, bool keepBackup = true);

// Reads into a temporary scene first; on any problem `scene` is left untouched.
bool read(const QString& path, Scene& scene, QString* error, QJsonObject* meta = nullptr);

}
