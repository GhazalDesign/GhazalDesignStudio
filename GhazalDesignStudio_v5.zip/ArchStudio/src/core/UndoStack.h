#pragma once
#include "Command.h"
#include <algorithm>
#include <memory>
#include <vector>

class UndoStack {
public:
    // Runs cmd->redo(). If it throws, the stack is untouched.
    void push(std::unique_ptr<Command> cmd, Scene& scene);
    void undo(Scene& scene);
    void redo(Scene& scene);

    bool canUndo() const { return m_index > 0; }
    bool canRedo() const { return m_index < int(m_cmds.size()); }
    QString undoText() const { return canUndo() ? m_cmds[m_index - 1]->text() : QString(); }
    QString redoText() const { return canRedo() ? m_cmds[m_index]->text() : QString(); }

    void setClean() { m_clean = m_index; }           // the saved state
    bool isClean() const { return m_index == m_clean; }
    void clear() { m_cmds.clear(); m_index = 0; m_clean = 0; }
    void setLimit(int n) { m_limit = std::max(1, n); }

private:
    static constexpr int kUnreachable = -2;           // the saved state fell out of the history
    std::vector<std::unique_ptr<Command>> m_cmds;
    int m_index = 0;
    int m_clean = 0;
    int m_limit = 500;
};
