#include "Document.h"
#include "Commands.h"
#include "ProjectFile.h"
#include <QCoreApplication>
#include <QDateTime>
#include <QFileInfo>
#include <QSet>
#include <algorithm>
#include <exception>

namespace {
QString trd(const char* s) { return QCoreApplication::translate("Document", s); }
}

Document::Document(QObject* parent) : QObject(parent) {}

QString Document::displayName() const
{
    return m_path.isEmpty() ? trd("Untitled") : QFileInfo(m_path).fileName();
}

bool Document::execute(std::unique_ptr<Command> cmd)
{
    try {
        m_undo.push(std::move(cmd), m_scene);
    } catch (const std::exception& e) {
        emit errorOccurred(trd("Command failed: %1").arg(QString::fromUtf8(e.what())));
        return false;
    }
    afterChange();
    return true;
}

void Document::afterChange()
{
    ++m_revision;
    const int before = int(m_selection.size());
    m_selection.erase(std::remove_if(m_selection.begin(), m_selection.end(),
                      [this](NodeId id) { return !m_scene.isSelectable(id); }), m_selection.end());
    if (!m_scene.hasLayer(m_currentLayer)) m_currentLayer = kDefaultLayer;
    emit sceneChanged();
    emit layersChanged();
    if (int(m_selection.size()) != before) emit selectionChanged();
    emit historyChanged();
    notifyDirty();
}

void Document::notifyDirty()
{
    if (m_lastDirty != isDirty()) {
        m_lastDirty = isDirty();
        emit titleChanged();
    }
}

// If undo/redo itself fails the history can no longer be trusted: drop it, keep the scene.
void Document::failHistory(const std::exception& e)
{
    m_undo.clear();
    m_forceDirty = true;
    emit errorOccurred(trd("Command failed: %1").arg(QString::fromUtf8(e.what())));
    afterChange();
}

NodeId Document::createNode(const QString& type, NodeId parent)
{
    if (!m_scene.layerUsable(m_currentLayer)) {
        emit errorOccurred(trd("The current layer is hidden, frozen or locked."));
        return kNoNode;
    }
    auto cmd = std::make_unique<CreateNodeCommand>(type, parent, m_currentLayer);
    CreateNodeCommand* raw = cmd.get();               // owned by the stack after execute()
    if (!execute(std::move(cmd))) return kNoNode;
    const NodeId id = raw->createdId();
    setSelection({ id });
    return id;
}

bool Document::deleteSelection()
{
    if (m_selection.isEmpty()) return false;
    const QSet<NodeId> sel(m_selection.begin(), m_selection.end());

    QVector<NodeId> tops;                              // skip nodes whose ancestor is also selected
    for (const NodeId id : m_selection) {
        bool covered = false;
        for (NodeId p = m_scene.node(id).parent; p != kNoNode; p = m_scene.node(p).parent)
            if (sel.contains(p)) { covered = true; break; }
        if (!covered) tops.append(id);
    }
    try {
        if (tops.size() == 1)
            return execute(std::make_unique<DeleteNodeCommand>(m_scene, tops[0]));
        auto macro = std::make_unique<MacroCommand>(trd("Delete %1 Objects").arg(tops.size()));
        for (const NodeId id : tops) macro->add(std::make_unique<DeleteNodeCommand>(m_scene, id));
        return execute(std::move(macro));
    } catch (const std::exception& e) {
        emit errorOccurred(trd("Command failed: %1").arg(QString::fromUtf8(e.what())));
        return false;
    }
}

bool Document::renameNode(NodeId id, const QString& newName)
{
    if (id == Scene::Root || !m_scene.contains(id)) return false;
    const QString name = newName.trimmed();
    if (name.isEmpty()) return false;
    if (name == m_scene.node(id).name) return true;
    return execute(std::make_unique<RenameNodeCommand>(m_scene, id, name));
}

bool Document::undo()
{
    if (!canUndo()) return false;
    try { m_undo.undo(m_scene); } catch (const std::exception& e) { failHistory(e); return false; }
    afterChange();
    return true;
}

bool Document::redo()
{
    if (!canRedo()) return false;
    try { m_undo.redo(m_scene); } catch (const std::exception& e) { failHistory(e); return false; }
    afterChange();
    return true;
}

void Document::setSelection(QVector<NodeId> ids)
{
    QVector<NodeId> clean;
    for (const NodeId id : ids)
        if (m_scene.isSelectable(id) && !clean.contains(id)) clean.append(id);
    if (clean == m_selection) return;
    m_selection = clean;
    emit selectionChanged();
}

void Document::newProject()
{
    m_scene = Scene();
    m_undo.clear();
    m_selection.clear();
    m_currentLayer = kDefaultLayer;
    m_path.clear();
    m_forceDirty = false;
    afterChange();
    emit selectionChanged();
    emit titleChanged();
}

bool Document::load(const QString& path, QString* error)
{
    Scene tmp;                                          // the open project stays intact if this fails
    if (!ProjectFile::read(path, tmp, error)) return false;
    m_scene = std::move(tmp);
    m_undo.clear();
    m_selection.clear();
    m_currentLayer = kDefaultLayer;
    m_path = path;
    m_forceDirty = false;
    afterChange();
    emit selectionChanged();
    emit titleChanged();
    return true;
}

bool Document::loadRecovered(const QString& snapshotPath, QString* error)
{
    Scene tmp;
    QJsonObject meta;
    if (!ProjectFile::read(snapshotPath, tmp, error, &meta)) return false;
    m_scene = std::move(tmp);
    m_undo.clear();
    m_selection.clear();
    m_currentLayer = kDefaultLayer;
    m_path = meta.value("originalPath").toString();
    m_forceDirty = true;
    afterChange();
    emit selectionChanged();
    emit titleChanged();
    return true;
}

bool Document::save(const QString& path, QString* error)
{
    if (!ProjectFile::write(path, m_scene, error)) return false;
    m_path = path;
    m_undo.setClean();
    m_forceDirty = false;
    notifyDirty();
    emit titleChanged();
    return true;
}

bool Document::saveSnapshot(const QString& snapshotPath, QString* error) const
{
    QJsonObject meta;
    meta["originalPath"] = m_path;
    meta["savedAt"] = QDateTime::currentDateTime().toString(Qt::ISODate);
    return ProjectFile::write(snapshotPath, m_scene, error, meta, /*keepBackup*/ false);
}

// ---------------------------------------------------------------- layers
void Document::setCurrentLayer(LayerId id)
{
    if (!m_scene.hasLayer(id) || id == m_currentLayer) return;
    m_currentLayer = id;
    emit layersChanged();
}

LayerId Document::createLayer()
{
    auto cmd = std::make_unique<CreateLayerCommand>("Layer");
    CreateLayerCommand* raw = cmd.get();
    if (!execute(std::move(cmd))) return 0;
    return raw->createdId();
}

bool Document::deleteLayer(LayerId id)
{
    try {
        return execute(std::make_unique<DeleteLayerCommand>(m_scene, id));
    } catch (const std::exception& e) {
        emit errorOccurred(trd("Command failed: %1").arg(QString::fromUtf8(e.what())));
        return false;
    }
}

bool Document::editLayer(const Layer& changed)
{
    if (!m_scene.hasLayer(changed.id)) return false;
    Layer n = changed;
    n.name = n.name.trimmed();
    if (n.name.isEmpty()) return false;
    const Layer& old = m_scene.layer(n.id);
    if (old.name == n.name && old.color == n.color && old.visible == n.visible
        && old.frozen == n.frozen && old.locked == n.locked) return true;
    try {
        return execute(std::make_unique<EditLayerCommand>(m_scene, n));
    } catch (const std::exception& e) {
        emit errorOccurred(trd("Command failed: %1").arg(QString::fromUtf8(e.what())));
        return false;
    }
}

bool Document::assignSelectionToLayer(LayerId id)
{
    if (m_selection.isEmpty() || !m_scene.hasLayer(id)) return false;
    try {
        auto cmd = std::make_unique<AssignLayerCommand>(m_scene, m_selection, id);
        if (cmd->isNoop()) return true;
        return execute(std::move(cmd));
    } catch (const std::exception& e) {
        emit errorOccurred(trd("Command failed: %1").arg(QString::fromUtf8(e.what())));
        return false;
    }
}
