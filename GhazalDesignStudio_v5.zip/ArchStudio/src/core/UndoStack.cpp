#include "UndoStack.h"

void UndoStack::push(std::unique_ptr<Command> cmd, Scene& scene)
{
    cmd->redo(scene);                                  // may throw: nothing recorded yet

    if (m_index < int(m_cmds.size())) {                // a new action discards the redo branch
        if (m_clean > m_index) m_clean = kUnreachable;
        m_cmds.erase(m_cmds.begin() + m_index, m_cmds.end());
    }
    m_cmds.push_back(std::move(cmd));
    ++m_index;

    while (int(m_cmds.size()) > m_limit) {             // bounded memory on long sessions
        m_cmds.erase(m_cmds.begin());
        --m_index;
        if (m_clean == 0) m_clean = kUnreachable; else if (m_clean > 0) --m_clean;
    }
}

void UndoStack::undo(Scene& scene)
{
    m_cmds[m_index - 1]->undo(scene);
    --m_index;
}

void UndoStack::redo(Scene& scene)
{
    m_cmds[m_index]->redo(scene);
    ++m_index;
}
