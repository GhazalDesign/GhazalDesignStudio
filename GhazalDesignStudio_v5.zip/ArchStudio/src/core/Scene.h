#pragma once
#include <QHash>
#include <QJsonObject>
#include <QString>
#include <QVector>
#include <cstdint>

// Core data model. Depends on QtCore only (no UI), so it is testable and safe to reuse.

using NodeId = std::uint64_t;
constexpr NodeId kNoNode = 0;

struct Vec3 { double x = 0, y = 0, z = 0; };

using LayerId = std::uint32_t;
constexpr LayerId kDefaultLayer = 1;           // always exists, cannot be deleted

struct Layer {
    LayerId id = 0;
    QString name;
    QString color = "#c8c8c8";
    bool visible = true;      // hidden layer: objects not drawn and not selectable
    bool frozen = false;      // frozen: visible but cannot be selected or edited
    bool locked = false;      // locked: same, but intended as a lighter "do not touch"

    QJsonObject toJson() const;
    static Layer fromJson(const QJsonObject& o);   // throws std::runtime_error
};

struct SceneNode {
    NodeId  id = kNoNode;
    NodeId  parent = kNoNode;
    LayerId layer = kDefaultLayer;
    QString type;                    // "Box", "Base Unit", ... (parametric templates later)
    QString name;
    Vec3    position, rotation, scale{1, 1, 1};   // mm / degrees
    bool    visible = true;
    bool    frozen = false;
    QJsonObject params;              // parametric values (width, height, panel thickness...)
    QVector<NodeId> children;        // maintained by Scene only

    QJsonObject toJson() const;
    static SceneNode fromJson(const QJsonObject& o);    // throws std::runtime_error
};

// Nodes are referenced by id, never by pointer: undo/redo and file loading stay safe.
class Scene {
public:
    static constexpr NodeId Root = 1;
    Scene();

    NodeId allocateId() { return m_next++; }        // ids are never reused
    bool   contains(NodeId id) const { return m_nodes.contains(id); }
    int    count() const { return int(m_nodes.size()); }
    const SceneNode& node(NodeId id) const;         // throws std::out_of_range
    SceneNode&       node(NodeId id);

    void insert(SceneNode n, int index = -1);       // attaches to n.parent
    void removeSubtree(NodeId id);                  // node + descendants; Root is protected
    QVector<SceneNode> collectSubtree(NodeId id) const;   // pre-order
    int  indexInParent(NodeId id) const;
    QString uniqueName(const QString& base) const;

    // layers
    const QVector<Layer>& layers() const { return m_layers; }
    LayerId allocateLayerId() { return m_nextLayer++; }
    bool hasLayer(LayerId id) const;
    const Layer& layer(LayerId id) const;           // throws std::out_of_range
    Layer&       layer(LayerId id);
    int  layerIndex(LayerId id) const;
    QString layerName(LayerId id) const;            // never throws
    void insertLayer(Layer l, int index = -1);
    void removeLayer(LayerId id);                   // objects on it fall back to the default layer
    QVector<NodeId> nodesOnLayer(LayerId id) const;
    QString uniqueLayerName(const QString& base) const;
    bool layerUsable(LayerId id) const;             // visible, not frozen, not locked
    bool isSelectable(NodeId id) const;

    QJsonObject toJson() const;
    void fromJson(const QJsonObject& o);            // validates; throws, leaving *this untouched

private:
    void reset();
    QHash<NodeId, SceneNode> m_nodes;
    NodeId m_next = Root + 1;
    QVector<Layer> m_layers;
    LayerId m_nextLayer = kDefaultLayer + 1;
};
