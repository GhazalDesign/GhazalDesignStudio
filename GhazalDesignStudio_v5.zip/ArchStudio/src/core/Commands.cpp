#include "Commands.h"
#include <QCoreApplication>
#include <stdexcept>

namespace {
QString trc(const char* s) { return QCoreApplication::translate("Command", s); }
}

QString CreateNodeCommand::text() const
{
    return trc("Create %1").arg(trc(m_type.toUtf8().constData()));
}

void CreateNodeCommand::redo(Scene& s)
{
    if (!m_created) {
        if (!s.contains(m_parent)) throw std::invalid_argument("parent does not exist");
        m_node.id = s.allocateId();
        m_node.parent = m_parent;
        m_node.type = m_type;
        m_node.layer = s.hasLayer(m_layer) ? m_layer : kDefaultLayer;
        m_node.name = s.uniqueName(m_type);
        m_created = true;
    }
    s.insert(m_node);
}

void CreateNodeCommand::undo(Scene& s) { s.removeSubtree(m_node.id); }

DeleteNodeCommand::DeleteNodeCommand(const Scene& s, NodeId id) : m_id(id)
{
    if (id == Scene::Root || !s.contains(id)) throw std::invalid_argument("cannot delete this node");
    m_name = s.node(id).name;
}

QString DeleteNodeCommand::text() const { return trc("Delete %1").arg(m_name); }

void DeleteNodeCommand::redo(Scene& s)
{
    m_index = s.indexInParent(m_id);
    m_subtree = s.collectSubtree(m_id);
    s.removeSubtree(m_id);
}

void DeleteNodeCommand::undo(Scene& s)
{
    for (int i = 0; i < m_subtree.size(); ++i)
        s.insert(m_subtree[i], i == 0 ? m_index : -1);     // pre-order keeps the children order
}

RenameNodeCommand::RenameNodeCommand(const Scene& s, NodeId id, QString newName)
    : m_id(id), m_new(newName.trimmed())
{
    if (m_new.isEmpty()) throw std::invalid_argument("empty name");
    m_old = s.node(id).name;
}

QString RenameNodeCommand::text() const { return trc("Rename %1").arg(m_old); }

void MacroCommand::redo(Scene& s)
{
    size_t done = 0;
    try {
        for (; done < m_cmds.size(); ++done) m_cmds[done]->redo(s);
    } catch (...) {
        for (size_t i = done; i-- > 0;) m_cmds[i]->undo(s);
        throw;
    }
}

void MacroCommand::undo(Scene& s)
{
    for (size_t i = m_cmds.size(); i-- > 0;) m_cmds[i]->undo(s);
}

QString CreateLayerCommand::text() const
{
    return trc("Create Layer %1").arg(m_created ? m_layer.name : m_base);
}

void CreateLayerCommand::redo(Scene& s)
{
    if (!m_created) {
        m_layer.id = s.allocateLayerId();
        m_layer.name = s.uniqueLayerName(m_base);
        m_created = true;
    }
    s.insertLayer(m_layer);
}

DeleteLayerCommand::DeleteLayerCommand(const Scene& s, LayerId id) : m_id(id)
{
    if (id == kDefaultLayer || !s.hasLayer(id)) throw std::invalid_argument("cannot delete this layer");
    m_layer = s.layer(id);
}

QString DeleteLayerCommand::text() const { return trc("Delete Layer %1").arg(m_layer.name); }

void DeleteLayerCommand::redo(Scene& s)
{
    m_layer = s.layer(m_id);
    m_index = s.layerIndex(m_id);
    m_moved = s.nodesOnLayer(m_id);
    s.removeLayer(m_id);
}

void DeleteLayerCommand::undo(Scene& s)
{
    s.insertLayer(m_layer, m_index);
    for (const NodeId n : m_moved) s.node(n).layer = m_id;
}

EditLayerCommand::EditLayerCommand(const Scene& s, Layer newState) : m_new(std::move(newState))
{
    m_new.name = m_new.name.trimmed();
    if (m_new.name.isEmpty()) throw std::invalid_argument("empty layer name");
    m_old = s.layer(m_new.id);                           // throws if unknown
}

QString EditLayerCommand::text() const { return trc("Edit Layer %1").arg(m_old.name); }

AssignLayerCommand::AssignLayerCommand(const Scene& s, const QVector<NodeId>& ids, LayerId layer) : m_layer(layer)
{
    if (!s.hasLayer(layer)) throw std::invalid_argument("unknown layer");
    m_layerName = s.layer(layer).name;
    for (const NodeId id : ids) {
        if (id == Scene::Root) continue;
        const LayerId old = s.node(id).layer;
        if (old != layer) m_changes.append({ id, old });
    }
}

QString AssignLayerCommand::text() const { return trc("Move to Layer %1").arg(m_layerName); }

void AssignLayerCommand::redo(Scene& s)
{
    for (const auto& c : m_changes) s.node(c.first).layer = m_layer;
}

void AssignLayerCommand::undo(Scene& s)
{
    for (const auto& c : m_changes) s.node(c.first).layer = c.second;
}
