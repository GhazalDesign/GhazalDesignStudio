#pragma once
#include "Command.h"
#include <memory>
#include <vector>

class CreateNodeCommand : public Command {
public:
    CreateNodeCommand(QString type, NodeId parent, LayerId layer = kDefaultLayer)
        : m_type(std::move(type)), m_parent(parent), m_layer(layer) {}
    NodeId createdId() const { return m_node.id; }
    QString text() const override;
    void redo(Scene& s) override;
    void undo(Scene& s) override;
private:
    QString m_type;
    NodeId  m_parent;
    LayerId m_layer;
    SceneNode m_node;
    bool m_created = false;       // id and name are fixed on first redo, so redo-after-undo is identical
};

class DeleteNodeCommand : public Command {
public:
    DeleteNodeCommand(const Scene& s, NodeId id);     // throws if id is unknown or the root
    QString text() const override;
    void redo(Scene& s) override;
    void undo(Scene& s) override;
private:
    NodeId m_id;
    QString m_name;
    int m_index = 0;
    QVector<SceneNode> m_subtree;   // full snapshot, pre-order
};

class RenameNodeCommand : public Command {
public:
    RenameNodeCommand(const Scene& s, NodeId id, QString newName);
    QString text() const override;
    void redo(Scene& s) override { s.node(m_id).name = m_new; }
    void undo(Scene& s) override { s.node(m_id).name = m_old; }
private:
    NodeId m_id;
    QString m_old, m_new;
};

// Several commands as one undo step. If one fails midway, the ones already applied are rolled back.
class MacroCommand : public Command {
public:
    explicit MacroCommand(QString text) : m_text(std::move(text)) {}
    void add(std::unique_ptr<Command> c) { m_cmds.push_back(std::move(c)); }
    QString text() const override { return m_text; }
    void redo(Scene& s) override;
    void undo(Scene& s) override;
private:
    QString m_text;
    std::vector<std::unique_ptr<Command>> m_cmds;
};

class CreateLayerCommand : public Command {
public:
    explicit CreateLayerCommand(QString baseName) : m_base(std::move(baseName)) {}
    LayerId createdId() const { return m_layer.id; }
    QString text() const override;
    void redo(Scene& s) override;
    void undo(Scene& s) override { s.removeLayer(m_layer.id); }
private:
    QString m_base;
    Layer m_layer;
    bool m_created = false;
};

// Objects on the deleted layer move to the default layer; undo puts them back.
class DeleteLayerCommand : public Command {
public:
    DeleteLayerCommand(const Scene& s, LayerId id);      // throws for the default layer / unknown id
    QString text() const override;
    void redo(Scene& s) override;
    void undo(Scene& s) override;
private:
    LayerId m_id;
    Layer m_layer;
    int m_index = 0;
    QVector<NodeId> m_moved;
};

// Rename, colour, visible, frozen, locked: one command for every layer property.
class EditLayerCommand : public Command {
public:
    EditLayerCommand(const Scene& s, Layer newState);
    QString text() const override;
    void redo(Scene& s) override { s.layer(m_new.id) = m_new; }
    void undo(Scene& s) override { s.layer(m_old.id) = m_old; }
private:
    Layer m_old, m_new;
};

class AssignLayerCommand : public Command {
public:
    AssignLayerCommand(const Scene& s, const QVector<NodeId>& ids, LayerId layer);
    bool isNoop() const { return m_changes.isEmpty(); }
    QString text() const override;
    void redo(Scene& s) override;
    void undo(Scene& s) override;
private:
    LayerId m_layer;
    QString m_layerName;
    QVector<QPair<NodeId, LayerId>> m_changes;           // node, previous layer
};
