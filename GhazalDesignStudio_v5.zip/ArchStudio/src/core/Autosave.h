#pragma once
#include <QDateTime>
#include <QList>
#include <QLockFile>
#include <QObject>
#include <QTimer>
#include <memory>
#include "Document.h"

// Crash protection. While a session runs it holds a lock file and writes a snapshot of any
// unsaved work every few seconds. A clean exit removes both. If the program crashes (or the
// power fails) the next start finds a lock file whose owner is gone, and offers recovery.
class AutosaveManager : public QObject {
    Q_OBJECT
public:
    struct Recoverable { QString snapshotPath; QString originalPath; QDateTime time; };

    explicit AutosaveManager(Document& doc, QObject* parent = nullptr);
    static QList<Recoverable> findCrashedSessions();    // newest first
    static void discard(const Recoverable& r);

    void start();
    void stop();                                         // clean exit

private:
    void tick();
    static QString autosaveDir();
    QString snapshotPath() const { return m_dir + "/" + m_id + ".gds"; }

    Document& m_doc;
    QString m_dir, m_id;
    std::unique_ptr<QLockFile> m_lock;
    QTimer m_timer;
    quint64 m_lastRevision = ~quint64(0);
    bool m_lastDirty = false;
};
