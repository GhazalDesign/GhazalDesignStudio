#pragma once
#include <QString>

// All colours of the application live here. Three themes: Dark, Gray, Light.
namespace Theme {

enum class Id { Dark, Gray, Light };

struct Palette {
    QString window, text, input, border, button, buttonHover, accent, accentText, menu, menuSel;
    QString vpBg, vpGrid, vpMajor, vpAxis, vpText, vpTop, vpBottom;   // viewports
};

inline Palette palette(Id id)
{
    switch (id) {
    case Id::Gray:
        return { "#595959", "#f0f0f0", "#474747", "#7a7a7a", "#6f6f6f", "#808080", "#d9a441", "#111111", "#4d4d4d", "#7a7a7a",
                 "#4a4a4a", "#5a5a5a", "#747474", "#262626", "#f2f2f2", "#707072", "#3a3a3c" };
    case Id::Light:
        return { "#e4e4e4", "#1e1e1e", "#ffffff", "#9a9a9a", "#f2f2f2", "#dde6f2", "#3a86d4", "#ffffff", "#f6f6f6", "#3a86d4",
                 "#d6d6d6", "#c4c4c4", "#a8a8a8", "#707070", "#202020", "#cfd6de", "#aab2bb" };
    default:
        return { "#3c3c3c", "#d0d0d0", "#2a2a2a", "#555555", "#4a4a4a", "#5b5b5b", "#5a9bd5", "#ffffff", "#2b2b2b", "#5a7fa8",
                 "#2a2a2a", "#3e3e3e", "#5f5f5f", "#141414", "#dcdcdc", "#464648", "#1c1c1e" };
    }
}

inline QString toName(Id id)
{
    return id == Id::Gray ? "gray" : id == Id::Light ? "light" : "dark";
}
inline Id fromName(const QString& n)
{
    return n == "gray" ? Id::Gray : n == "light" ? Id::Light : Id::Dark;
}

inline QString styleSheet(Id id)
{
    const Palette p = palette(id);
    QString s = R"(
* { font-size: 11px; color: @text@; }
QMainWindow, QDockWidget, QWidget#panel { background: @window@; }
QMenuBar { background: @menu@; }
QMenuBar::item:selected, QMenu::item:selected { background: @menuSel@; color: @accentText@; }
QMenu { background: @menu@; border: 1px solid @border@; }
QToolBar { background: @window@; border: none; spacing: 2px; padding: 1px; }
QToolButton { background: @button@; border: 1px solid @border@; padding: 3px 6px; min-width: 18px;
              font-family: "Segoe UI Symbol", "Segoe UI"; }
QToolButton:hover { background: @buttonHover@; }
QToolButton:checked { background: @accent@; color: @accentText@; }
QTabBar::tab { background: @button@; padding: 3px 12px; border: 1px solid @border@; }
QTabBar::tab:selected { background: @buttonHover@; }
QComboBox, QLineEdit, QDoubleSpinBox { background: @input@; border: 1px solid @border@; padding: 1px 3px; }
QComboBox QAbstractItemView { background: @input@; selection-background-color: @menuSel@; }
QGroupBox { border: 1px solid @border@; margin-top: 9px; padding-top: 6px; }
QGroupBox::title { subcontrol-origin: margin; left: 8px; }
QPushButton { background: @button@; border: 1px solid @border@; padding: 3px; }
QPushButton:hover { background: @buttonHover@; }
QTreeWidget { background: @input@; border: 1px solid @border@; }
QHeaderView::section { background: @button@; color: @text@; border: 1px solid @border@; padding: 2px; }
QStatusBar { background: @menu@; }
QSlider::groove:horizontal { height: 14px; background: @input@; border: 1px solid @border@; }
QSlider::handle:horizontal { width: 12px; background: #d9a441; }
QSplitter::handle { background: @border@; }
QDialog { background: @window@; }
QAbstractItemView { background: @input@; }
QToolTip { background: @input@; color: @text@; border: 1px solid @border@; }
)";
    const QList<QPair<QString, QString>> map = {
        {"@window@", p.window}, {"@text@", p.text}, {"@input@", p.input}, {"@border@", p.border},
        {"@buttonHover@", p.buttonHover}, {"@button@", p.button}, {"@accentText@", p.accentText},
        {"@accent@", p.accent}, {"@menuSel@", p.menuSel}, {"@menu@", p.menu} };
    for (const auto& kv : map) s.replace(kv.first, kv.second);
    return s;
}
}
