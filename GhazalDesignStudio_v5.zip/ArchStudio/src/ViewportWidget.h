#pragma once
#include <QWidget>
#include "Theme.h"

enum class ViewType { Top, Front, Left, Perspective };

// Placeholder viewport (QPainter). Will be replaced by a Vulkan/RHI renderer
// in a later phase; the interface (name, active state, signals) stays the same.
class ViewportWidget : public QWidget {
    Q_OBJECT
public:
    explicit ViewportWidget(ViewType type, QWidget* parent = nullptr);
    void setActive(bool a);
    void applyTheme(const Theme::Palette& p) { m_pal = p; update(); }
    ViewType type() const { return m_type; }

signals:
    void activated(ViewportWidget* self);

protected:
    void paintEvent(QPaintEvent*) override;
    void mousePressEvent(QMouseEvent*) override;
    void mouseMoveEvent(QMouseEvent*) override;
    void wheelEvent(QWheelEvent*) override;

private:
    QString title() const;
    ViewType m_type;
    bool m_active = false;
    Theme::Palette m_pal = Theme::palette(Theme::Id::Dark);
    double m_zoom = 1.0;
    double m_yaw = 0.6, m_pitch = 0.6;
    QPoint m_last;
};
