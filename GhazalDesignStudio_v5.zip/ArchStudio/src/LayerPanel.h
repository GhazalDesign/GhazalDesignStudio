#pragma once
#include <QWidget>
#include "Document.h"

class QTableWidget;

// Layer Manager: list of layers with current / name / visible / freeze / lock / colour.
// Every change goes through the Document, so it is undoable.
class LayerPanel : public QWidget {
    Q_OBJECT
public:
    explicit LayerPanel(Document& doc, QWidget* parent = nullptr);

private:
    void scheduleRefresh();
    void refresh();
    LayerId selectedLayer() const;

    Document& m_doc;
    QTableWidget* m_table = nullptr;
    bool m_pending = false;
};
