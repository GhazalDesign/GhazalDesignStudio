# One-click build + tests. Usage:
#   powershell -ExecutionPolicy Bypass -File .\build.ps1 -Run
param([switch]$Run, [switch]$Clean, [switch]$SkipTests, [string]$Qt = "C:/Qt/6.12.0/msvc2022_64")
$ErrorActionPreference = "Stop"

# 1) MSVC environment
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$vsPath = if (Test-Path $vswhere) { & $vswhere -latest -products * -property installationPath } else { $null }
if (-not $vsPath) { $vsPath = (Get-ChildItem "$env:ProgramFiles\Microsoft Visual Studio\*\*" -Directory | Select-Object -First 1).FullName }
$vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvars64.bat"
cmd /c "`"$vcvars`" && set" | ForEach-Object {
    if ($_ -match '^(.*?)=(.*)$') { Set-Item -Path "Env:$($matches[1])" -Value $matches[2] }
}

# 2) CMake + Ninja that ship with Qt
$env:PATH += ";C:\Qt\Tools\CMake_64\bin;C:\Qt\Tools\Ninja"

# 3) Build
Set-Location $PSScriptRoot
if ($Clean -and (Test-Path build)) { Remove-Item build -Recurse -Force }
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$Qt"
cmake --build build
if ($LASTEXITCODE -ne 0) { throw "Build failed" }
& "$Qt/bin/windeployqt.exe" build/GhazalDesignStudio.exe | Out-Null

# 4) Automated tests (stop if any fails)
if (-not $SkipTests -and (Test-Path build/core_tests.exe)) {
    & "$Qt/bin/windeployqt.exe" build/core_tests.exe | Out-Null
    & ./build/core_tests.exe
    if ($LASTEXITCODE -ne 0) { throw "Tests failed - not launching" }
}

if ($Run) { & ./build/GhazalDesignStudio.exe }
